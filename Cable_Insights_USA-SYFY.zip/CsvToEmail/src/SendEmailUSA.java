import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.rmi.CORBA.Util;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.opencsv.CSVReader;

public class SendEmailUSA {

	DateFormat folderDateFormate = new SimpleDateFormat("yyyy-MM-dd");
	DateFormat standardDateFormat = new SimpleDateFormat("M/d/yyyy");
	DateFormat fileDateFormat = new SimpleDateFormat("MMddyyyy");
	DateFormat startTimeFormat = new SimpleDateFormat("hh:mm a");

	DataFormatter dataFormat = new DataFormatter();

	String programCompDir = "D:\\Cable_Insights\\Time_Period_Comparison";
	String programRankerDir = "D:\\Cable_Insights\\Program_Ranker";
	String rptPmrDir = "D:\\Cable_Insights\\Time_Period_Comparison_Rpt_Pmr";

	Address[] successEmailIds;
	Address[] failureEmailIds;

	public static void main(String[] args) throws ParseException {

		String[] emailIds = System.getProperty("emailIds").split(",");

		SendEmailUSA sendEmail = new SendEmailUSA();

		sendEmail.successEmailIds = new InternetAddress[emailIds.length];

		System.out.println("Loading email ids from arguments list...");

		try {

			for (int i = 0; i < emailIds.length; i++)
				sendEmail.successEmailIds[i] = new InternetAddress(emailIds[i]);

			sendEmail.failureEmailIds = new Address[] {

					new InternetAddress("Vaneet.Kumar@nbcuni.com"),
					new InternetAddress("santhosh.medar@nbcuni.com"),
					new InternetAddress("Kratika.Sharma@nbcuni.com") 
			};

			sendEmail.sendCsvAsEmail();
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			Utils.getStackTrace(e);
		}

	}

	private void sendCsvAsEmail() throws ParseException {

		CSVReader csvReader = null;
		Workbook workbook = null;
		String from = "CableInsights-donotreply@nbcuni.com"; // change
		// accordingly
		String host = "nbcumail.inbcu.com";// or IP address
		// Get the session object
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);

		File[] pgmCompFiles = new File(programCompDir).listFiles();
		File[] pgmRnkFiles = new File(programRankerDir).listFiles();

		Map<String, List<File>> pgmCompList = new TreeMap<>();
		Map<String, File> pgmRnkrList = new HashMap<>();


		if (pgmCompFiles.length != 0 || pgmRnkFiles.length != 0) try {
			System.out.println("Files found! waiting for all files deployment (2 mins)...");
			Thread.sleep(120000); } catch (InterruptedException e1) {
			Utils.getStackTrace(e1);	
			}


		for (File file : pgmCompFiles) {
			if (file.isFile()) {
				String net = file.getName().split("-")[0].trim();

				if (net.equals("USA") || net.equals("SYFY")) {

					String date = file.getName().split("\\.")[1];
					List<File> filesList = pgmCompList.get(date);

					if (filesList != null) {
						filesList.add(file);
					} else {
						filesList = new ArrayList<>();
						filesList.add(file);
						pgmCompList.put(date, filesList);
					}
				}
			}
		}

		for (File file : pgmRnkFiles) {
			if (file.isFile()) {
				String date = file.getName().split("\\.")[1];
				pgmRnkrList.put(date, file);
			}
		}

		Set<String> allDates = new TreeSet<String>();
		allDates.addAll(pgmRnkrList.keySet());
		allDates.addAll(pgmCompList.keySet());

		for (String fileDate : allDates) {
			System.out.println("Running for "+fileDate+"...");
			try {

				String frmtdBodyMsg = "<body style=\"font-family: 'Calibri','sans-serif';\">"
						+ "<b style=\"font-size: 13.0pt;color: black;font-weight: bold;\"> <u> USA & SYFY Daily Ratings </u></b><br>"
						+ standardDateFormat.format(fileDateFormat.parse(fileDate))
						+ "<br> <i style=\"font-size: 10.2pt;\">Premieres are in bold and compared to the prior four week rolling season average, all other telecasts                     are compared to the prior four week time period average. </i><br>";

				if (pgmCompList.get(fileDate) != null && pgmCompList.get(fileDate).size() == 2
						&& pgmRnkrList.get(fileDate) != null) {

					File[] pgmCompFileList = pgmCompList.get(fileDate).toArray(new File[2]);
					File pgmRankrFile = pgmRnkrList.get(fileDate);

					Map<String, String[]> netDemos = new HashMap<>();
					netDemos.put("USA", new String[] { "P18-49", "P2+" });
					netDemos.put("SYFY", new String[] { "P18-49", "P2+" });

					Map<Integer, String> colWidths = new HashMap<>();
					colWidths.put(0, "100px");
					colWidths.put(1, "204px");
					colWidths.put(2, "186px");
					colWidths.put(3, "60px");
					colWidths.put(4, "60px");

					Map<Integer, String> demoBgColors = new HashMap<>();
					demoBgColors.put(0, "#E2EFDA");
					demoBgColors.put(1, "#FFF2CC");
					demoBgColors.put(2, "#ffe6e6");

					File rptPmrFile = null;
					for (File file : new File(rptPmrDir).listFiles()) {
						if (file.getName().contains(fileDate) && file.getName().contains("USA"))
							rptPmrFile = file;
					}

					if (rptPmrFile != null) {

						System.out.println("Program Comparison, Comp. Network and Indicators files found for "+fileDate);

						Workbook rptPmrWrkbook = WorkbookFactory.create(rptPmrFile);
						Sheet rptPmrSheet = rptPmrWrkbook.getSheetAt(0);

						Map<String, Integer> rptPmrCols = new HashMap<>();
						for (int i = 0; i < rptPmrSheet.getRow(0).getLastCellNum(); i++)
							rptPmrCols.put(dataFormat.formatCellValue(rptPmrSheet.getRow(0).getCell(i)), i);

						Map<String, Boolean> colsRptPmr = new HashMap<>();

						System.out.println("Loading data from Indicators file...");
						System.out.println(rptPmrFile);

						for (int i = 1; i <= rptPmrSheet.getLastRowNum(); i++) {

							String net = dataFormat
									.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("Net")));
							String show = dataFormat
									.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("Show Name")));
							String startTime = startTimeFormat.parse(dataFormat
									.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("Start Time"))))
									.toString();
							String rptPmr = dataFormat
									.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("P/R")));

							if(rptPmrCols.get("Non Commercial") != null){
								String nonCommInd = dataFormat.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("Non Commercial")));

								if(nonCommInd.trim().equals("") && (rptPmr.trim().equals("") || rptPmr.trim().equals("P")))
									colsRptPmr.put(net + show + startTime, true);

							}else{
								if(rptPmr.trim().equals("") || rptPmr.trim().equals("P"))
									colsRptPmr.put(net + show + startTime, true);
							}
						}

						rptPmrWrkbook.close();

						System.out.println("Processing Program Comparison files...");

						Arrays.sort(pgmCompFileList, new Comparator<File>() {

							@Override
							public int compare(File f1, File f2) {
								return f2.getName().compareTo(f1.getName());
							}
						});

						// Iterating to create 2 tables, for USA & SYFY Network
						for (File filePath : pgmCompFileList) {

							System.out.println(filePath);

							List<Integer> validColInd = new ArrayList<>();
							// creating a workbook for the file
							workbook = WorkbookFactory.create(filePath);
							// Getting sheet at 0 index
							Sheet sheet = workbook.getSheetAt(0);

							String network = sheet.getRow(0).getCell(0).toString().trim();
							String dateValue = sheet.getRow(1).getCell(0).toString().trim();
							standardDateFormat.format(standardDateFormat.parse(dateValue));

							frmtdBodyMsg += "<br>"
									+ "<span style=\"font-size:14.0pt;color:black;font-family:'Calibri','sans-serif';font-weight: bold;\">"
									+ network + "<br>"
									+ "<table style=\"width: 1000px;white-space: nowrap;border-collapse: collapse;font-size: 12pt;font-family: 'Calibri','sans-serif';border: 1px solid black;\">"
									+ "<thead> "
									+ "<tr style=\"background-color:#737373;border-color: #737373;color: white;\">";

							String headerHtml = "<th style=\"padding:5px;%s;\"> %s </th>";

							Set<Integer> columnOrder = new TreeSet<Integer>();

							for (int j = 0; j < sheet.getRow(4).getLastCellNum(); j++) {
								boolean validDemos = false;
								for (String demo : netDemos.get(network)) {
									if (j >= 1 && (sheet.getRow(4).getCell(j).toString().contains(demo)
											|| sheet.getRow(4).getCell(j - 1).toString().contains(demo))) {
										validDemos = true;
										columnOrder.add(j);
										break;
									}
								}

								if (j <= 2 || validDemos) {

									String colName = sheet.getRow(4).getCell(j).toString();
									if (colName.contains("% Diff ")) {
										colName = "% vp4w";
									}
									if (colName.contains("(000)")) {
										colName = colName.replace("_x000d_\nLS_x000d_\nImps_x000d_\n", " ");
									}

									if (j <= 2)
										frmtdBodyMsg += String.format(headerHtml, "text-align:left;width:"+colWidths.get(j), colName);
									else if (j % 2 == 1)
										frmtdBodyMsg += String.format(headerHtml,
												"text-align:center;width:" + colWidths.get(3), colName);
									else
										frmtdBodyMsg += String.format(headerHtml,
												"text-align:center;width:" + colWidths.get(4), colName);

									validColInd.add(j);
								}

							}

							frmtdBodyMsg += "</tr> </thead> <tbody>";

							for (int i = 5; i <= sheet.getLastRowNum(); i++) {
								System.out.println();
								frmtdBodyMsg += "<tr>";
								int demoColInd = 0;

								String netShowTime = null;
								try {
									netShowTime = network + dataFormat.formatCellValue(sheet.getRow(i).getCell(1))
									+ startTimeFormat
									.parse(dataFormat.formatCellValue(sheet.getRow(i).getCell(0)))
									.toString();
								} catch (ParseException e) {

								}

								for (int j = 0; j < sheet.getRow(i).getLastCellNum(); j++) {
									if (validColInd.indexOf(j) >= 0) {

										String td = null;
										String style = "padding-right:5px;padding-left:5px;";

										if (j == 0) {
											style += "text-align:left;width:160px;";
											td = "<td style=\"%s\">"
													+ dataFormat.formatCellValue(sheet.getRow(i).getCell(j)) + "</td>";

										}
										if (j > 0 && j <= 2) {
											style += "text-align:left;padding-left:5px;width:200px;";
											td = "<td style=\"%s\">"
													+ dataFormat.formatCellValue(sheet.getRow(i).getCell(j)) + "</td>";
										}
										if (j > 2) {
											style += "text-align:center;padding-left:5px;";
											td = "<td style=\"%s\">"
													+ String.valueOf(
															(int) sheet.getRow(i).getCell(j).getNumericCellValue())
													+ "</td>";
										}
										if (j == 3) {
											style += "background:" + demoBgColors.get(demoColInd++) + ";";
											td = "<td style=\"%s\">"
													+ String.valueOf(
															(int) sheet.getRow(i).getCell(j).getNumericCellValue())
													+ "</td>";
										}
										if (j == 5) {
											style += "background:" + demoBgColors.get(demoColInd++) + ";";
											td = "<td style=\"%s\">"
													+ String.valueOf(
															(int) sheet.getRow(i).getCell(j).getNumericCellValue())
													+ "</td>";
										}

										if (j == 4 || j == 6) {

											String percval = dataFormat.formatCellValue(sheet.getRow(i).getCell(j));

											if (percval != null && !percval.equals("") && Integer.parseInt(percval.split("%")[0]) < 0)
												style += "color:red;";
											if (percval != null && !percval.equals("") && Integer.parseInt(percval.split("%")[0]) > 0)
												style += "color:green;";

											if(percval != null && !percval.equals("")){
												if (Integer.parseInt(percval.split("%")[0]) > 0)
													td = "<td style=\"%s\">+" + percval.split("%")[0] + "</td>";
												else
													td = "<td style=\"%s\">" + percval.split("%")[0] + "</td>";
											}else
												td = "<td></td>";

										}

										if (j == 1) {
											style += "text-align:left;padding-left:5px;white-space:nowrap;";
											String showName = dataFormat.formatCellValue(sheet.getRow(i).getCell(j));
											if (showName.length() > 20) {

												td = "<td style=\"%s\">" + showName.substring(0, 20) + "..." + "</td>";
											} else {
												td = "<td style=\"%s\">" + showName + "</td>";
											}

										}

										if (j == 2) {
											style += "text-align:left;padding-left:5px;white-space:nowrap;";
											String episode = dataFormat.formatCellValue(sheet.getRow(i).getCell(j));
											if (episode.length() > 20) {

												td = "<td style=\"%s\">" + episode.substring(0, 20) + "..." + "</td>";
											} else {
												td = "<td style=\"%s\">" + episode + "</td>";
											}
										}

										if ((i == sheet.getLastRowNum() || i == sheet.getLastRowNum() - 1) || i == sheet.getLastRowNum()-2)
											style += "font-weight:bold;";

										if (i == sheet.getLastRowNum() - 2)
											style += "background:#D9D9D9;border-top: 1px solid black;";

										if (i == sheet.getLastRowNum() - 1)
											style += "background:#BFBFBF;border-top: 1px solid black;";

										else if (i == sheet.getLastRowNum())
											style += "background:#a6a6a6;border-top: 1px solid black;";

										if (colsRptPmr.get(netShowTime) != null && colsRptPmr.get(netShowTime))
											style += "font-weight:bold;";

										td = String.format(td, style);

										if ((j == 4 || j == 6) && !td.equals("<td></td>"))
											td = td.replace("</", "%</");

										frmtdBodyMsg += td;

									}
								}

								frmtdBodyMsg += "</tr>";
							}
							frmtdBodyMsg += "</tbody> </table>";
							workbook.close();
						}

						System.out.println("Processing Pram Ranker file...");
						System.out.println(pgmRankrFile);

						@SuppressWarnings("resource")
						CSVReader csvReader2 = new CSVReader(new FileReader(pgmRankrFile));
						String[] impsColors = { "#548235", "#649146", "#7BA65E", "#7BA65E", "#84AE67", "#8BB46F",
								"#8EB872", "#8FB973", "#91BA75", "#94BD78", "#99C27E", "#A0C885", "#A7CE8C", "#A7CE8C",
								"#A8D08D", "#ABD291", "#B3D69B", "#B5D79D", "#BDDBA8", "#BFDCAB", "#C2DEAF", "#C3DFB0",
								"#C4DFB1", "#C4DFB1", "#C4DFB1", "#C4DFB1", "#C4DFB2", "#C5E0B2", "#C6E0B4",
						"#C6E0B4" };

						Map<String, Integer> colsAndInd = new HashMap<>();

						List<String[]> rankers = csvReader2.readAll();

						frmtdBodyMsg += "<br><br>"
								+ "<span style=\"font-size:14.0pt;color:black;font-family:'Calibri','sans-serif';font-weight: bold;\"> Top 30 P18-49 LS Telecast "
								+ "</span>" + "<br>"
								+ "<table style=\"width: 875px;;white-space: nowrap;border-collapse: collapse;font-family: 'Calibri','sans-serif';text-align: left;border: 1px solid black;\">"
								+ "<thead><tr style=\"background-color:gray;border-color: #A6A6A6;color: white;\">";

						frmtdBodyMsg += "<th style=\"padding-left:5px;padding-right:5px;text-align:left;text-align:center;\">Rank</th>";
						frmtdBodyMsg += "<th style=\"padding-left:5px;padding-right:5px;text-align:left;width:70px;\">Network</th>";
						frmtdBodyMsg += "<th style=\"padding-left:5px;padding-right:5px;text-align:left;white-space:nowrap;\">Program</th>";
						frmtdBodyMsg += "<th style=\"padding-left:5px;padding-right:5px;text-align:left;white-space:nowrap;\">Episode Title</th>";
						frmtdBodyMsg += "<th style=\"padding-left:5px;padding-right:5px;width: 60px;text-align:left;\">S Time</th>";
						frmtdBodyMsg += "<th style=\"padding-left:5px;padding-right:5px;text-align:center;width:100px;\">P18-49 (000)</th>";
						frmtdBodyMsg += "</tr></thead><tbody>";

						for (int k = 0; k < rankers.get(0).length; k++)
							colsAndInd.put(rankers.get(0)[k], k);

						rankers.remove(0);

						TreeSet<String[]> sortedRankers = new TreeSet<>(new Comparator<String[]>() {

							@Override
							public int compare(String[] a, String[] b) {

								int diff = Integer.parseInt(b[colsAndInd.get("AA (000)")])
										- Integer.parseInt(a[colsAndInd.get("AA (000)")]);

								if(diff == 0) 
									diff = (a[colsAndInd.get("NETWORK")]+a[colsAndInd.get("S TIME")]).compareTo((b[colsAndInd.get("NETWORK")]+b[colsAndInd.get("S TIME")]));


								return diff;
							}

						});

						sortedRankers.addAll(rankers);

						int rowNum = 0;
						int rank = rowNum;
						int prevImps = Integer.MAX_VALUE;

						Map<String, String> usaSyfyColors = new HashMap<>();
						usaSyfyColors.put("USA", "#8DB5E7");
						usaSyfyColors.put("SYFY", "#B7A4E6");

						for (Iterator<String[]> it = sortedRankers.iterator(); it.hasNext();) {

							String[] line = it.next();

							if (!line[colsAndInd.get("Stream")].equals("LS")
									|| !line[colsAndInd.get("Demo")].equals("P18-49"))
								continue;

							rowNum++;

							if (Integer.parseInt(line[colsAndInd.get("AA (000)")]) < prevImps)
								rank = rowNum;

							if(rank > 30)
								break;

							prevImps = Integer.parseInt(line[colsAndInd.get("AA (000)")]);



							if (line[colsAndInd.get("NETWORK")].equals("USA")
									|| line[colsAndInd.get("NETWORK")].equals("SYFY")) {
								frmtdBodyMsg += "<tr>";

								frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;text-align:center;width:70px;background:"+usaSyfyColors.get(line[colsAndInd.get("NETWORK")])+";\">"
										+ rank + "</td>";

								frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;width:70px;background:"+usaSyfyColors.get(line[colsAndInd.get("NETWORK")])+";\">"
										+ line[colsAndInd.get("NETWORK")] + "</td>";

								if (line[colsAndInd.get("PROGRAM")].toString().length() > 20) {
									String program = line[colsAndInd.get("PROGRAM")].toString().substring(0, 20)
											+ "...";
									frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;white-space:nowrap;width:200px;background:"+usaSyfyColors.get(line[colsAndInd.get("NETWORK")])+";\">"
											+ program + "</td>";
								} else {
									frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;white-space:nowrap;width:200px;background:"+usaSyfyColors.get(line[colsAndInd.get("NETWORK")])+";\">"
											+ line[colsAndInd.get("PROGRAM")] + "</td>";
								}

								if (line[colsAndInd.get("EPISODE TITLE")].toString().length() > 20) {

									String episode = line[colsAndInd.get("EPISODE TITLE")].toString().substring(0, 20)
											+ "...";
									frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;white-space:nowrap;width:250px;background:"+usaSyfyColors.get(line[colsAndInd.get("NETWORK")])+";\">"
											+ episode + "</td>";
								} else {
									frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;white-space:nowrap;width:250px;background:"+usaSyfyColors.get(line[colsAndInd.get("NETWORK")])+";\">"
											+ line[colsAndInd.get("EPISODE TITLE")] + "</td>";
								}

								frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;text-align:left;background:"+usaSyfyColors.get(line[colsAndInd.get("NETWORK")])+";\">"
										+ line[colsAndInd.get("S TIME")] + "</td>";

								frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;text-align:center;width:100px;background:"+usaSyfyColors.get(line[colsAndInd.get("NETWORK")])+";\">"
										+ line[colsAndInd.get("AA (000)")] + "</td>";

							} else {

								frmtdBodyMsg += "<tr>";

								frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;text-align:center;width:70px;\">"
										+rank+ "</td>";

								frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;width:70px;\">"
										+ line[colsAndInd.get("NETWORK")] + "</td>";

								if (line[colsAndInd.get("PROGRAM")].toString().length() > 20) {
									String program = line[colsAndInd.get("PROGRAM")].toString().substring(0, 20)
											+ "...";
									frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;white-space:nowrap;width:200px;\">"
											+ program + "</td>";
								} else {
									frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;white-space:nowrap;width:200px;\">"
											+ line[colsAndInd.get("PROGRAM")] + "</td>";
								}

								if (line[colsAndInd.get("EPISODE TITLE")].toString().length() > 20) {

									String episode = line[colsAndInd.get("EPISODE TITLE")].toString().substring(0, 20)
											+ "...";
									frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;white-space:nowrap;width:250px;\">"
											+ episode + "</td>";
								} else {
									frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;white-space:nowrap;width:250px;\">"
											+ line[colsAndInd.get("EPISODE TITLE")] + "</td>";
								}

								frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;text-align:left;\">"
										+ line[colsAndInd.get("S TIME")] + "</td>";



								frmtdBodyMsg += "<td style=\"padding-left:5px;padding-right:5px;background-color:#E2EFDA"
										//+ impsColors[rank-1] + ""
										+ ";text-align:center;width:100px;\">"
										+ line[colsAndInd.get("AA (000)")] + "</td>";

							}

							frmtdBodyMsg += "</tr>";

						}

						frmtdBodyMsg += "</tbody></table>";
						csvReader2.close();

						System.out.println("Tables successfully created");
						System.out.println("Sending email...");

						/*to = new Address[] { 

								//new InternetAddress("ted.linhart@nbcuni.com"),
								//new InternetAddress("kerry.billings@nbcuni.com"),
								//new InternetAddress("Neda.Garemani@nbcuni.com"),
								//new InternetAddress("Vaneet.Kumar@nbcuni.com"),
								//new InternetAddress("Kratika.Sharma@nbcuni.com"),
								new InternetAddress("santhosh.medar@nbcuni.com"),
								//new InternetAddress("Kondapa.Chittabathina@nbcuni.com"),
								// new InternetAddress("Vaneet.Kumar@nbcuni.com"),
								// new InternetAddress("ted.linhart@nbcuni.com"),
								// new InternetAddress("Jennifer.Livolsi@nbcuni.com"),

						};*/

						String emailSub = "USA/SYFY - Cable Insights - "
								+ (standardDateFormat.format(fileDateFormat.parse(fileDate)));

						Session session = Session.getDefaultInstance(properties);
						// compose the message
						MimeMessage message = new MimeMessage(session);
						message.setFrom(new InternetAddress(from));
						message.addRecipients(Message.RecipientType.TO, successEmailIds);
						message.setSubject(emailSub);

						message.setContent(frmtdBodyMsg, "text/html");

						// Send message
						Transport.send(message);
						System.out.println("Email sent successfully");

						//move files to archive

						System.out.println("Moving files to processed folder...");

						File destDirectory = new File("D:\\Cable_Insights\\USA-SYFY_Archive\\"+folderDateFormate.format(new Date()));


						for (File file : pgmCompFileList)
						{
							File destFile = new File(destDirectory.getAbsolutePath()+"\\"+file.getName());
							if(destFile.exists())
							{
								destFile.delete();
								System.out.println(destFile.getAbsolutePath()+" file deleted since it alreday exists");
							}

							try {
								FileUtils.moveFileToDirectory(file, destDirectory, true);
								System.out.println(file.getName()+" is successfully moved to "+destDirectory.getAbsolutePath());
							} catch (IOException e) {
								System.out.println(new Date().toString() + " Failed to move Excel files to archive folder!");

							}

						}

						//workbook.close();
						File destFile = new File(destDirectory.getAbsolutePath()+"\\"+pgmRankrFile.getName());
						//File destFile = new File(destDirectory.getAbsolutePath()+"\\"+compNetList.get(fileDate));

						if(destFile.exists())
						{
							destFile.delete();
							System.out.println(destFile.getAbsolutePath()+" file deleted since it alreday exists");
						}

						try {
							FileUtils.moveFileToDirectory(pgmRankrFile, destDirectory, true);
							System.out.println(pgmRankrFile.getName()+" is successfully moved to "+destDirectory.getAbsolutePath());
						} catch (IOException e) {
							System.out.println(new Date().toString() + " Failed to move Excel files to archive folder!");

						}

						File rptPmrDestFile = new File(destDirectory.getAbsolutePath()+"\\"+rptPmrFile.getName());
						//File destFile = new File(destDirectory.getAbsolutePath()+"\\"+compNetList.get(fileDate));

						if(rptPmrDestFile.exists())
						{
							rptPmrDestFile.delete();
							System.out.println(rptPmrDestFile.getAbsolutePath()+" file deleted since it alreday exists");
						}

						try {
							FileUtils.moveFileToDirectory(rptPmrFile, destDirectory, true);
							System.out.println(rptPmrFile.getName()+" is successfully moved to "+destDirectory.getAbsolutePath());
						} catch (IOException e) {
							System.out.println(new Date().toString() + " Failed to move Excel files to archive folder!");

						}


					} else {

						System.out.println("Repeat/Premier Indicator file not found for "
								+ standardDateFormat.format(fileDateFormat.parse(fileDate)));

						frmtdBodyMsg = "<p> Repeat/Premier Indicator file not found for "
								+ standardDateFormat.format(fileDateFormat.parse(fileDate)) + "</p>";

						System.out.println("Sending email internally");

						Session session = Session.getDefaultInstance(properties);

						// compose the message
						String emailSub = "USA/SYFY - Cable Insights - "
								+ standardDateFormat.format(fileDateFormat.parse(fileDate));
						MimeMessage message = new MimeMessage(session);
						message.setSubject(emailSub);
						message.setFrom(new InternetAddress(from));
						message.addRecipients(Message.RecipientType.TO, failureEmailIds);

						message.setContent(frmtdBodyMsg, "text/html");

						// Send message
						Transport.send(message);
						System.out.println("Email sent successfully");
					}

				} else {

					if (pgmCompList.get(fileDate) == null){
						System.out.println("There are no Time Period Comparison files found for " + fileDate);
						frmtdBodyMsg = "<p>There are no Time Period Comparison files found for " + fileDate + ".</p>";
					}
					else if (pgmCompList.get(fileDate).size() != 2){
						System.out.println("There are less or more than 2 files found for Time Period Comparison for "
								+ fileDate);

						frmtdBodyMsg = "<p>There are less or more than 2 files found for Time Period Comparison for "
								+ fileDate + ".</p>";
					}

					if (pgmRnkrList.get(fileDate) == null){
						System.out.println("Program Ranker file not found for "
								+ standardDateFormat.format(fileDateFormat.parse(fileDate)));
						frmtdBodyMsg = "<p> Program Ranker file not found for "
								+ standardDateFormat.format(fileDateFormat.parse(fileDate)) + "</p>";
					}

					System.out.println("Sending email internally...");
					Session session = Session.getDefaultInstance(properties);

					// compose the message
					String emailSub = "USA/SYFY - Cable Insights - "
							+ standardDateFormat.format(fileDateFormat.parse(fileDate));
					MimeMessage message = new MimeMessage(session);
					message.setSubject(emailSub);
					message.setFrom(new InternetAddress(from));
					message.addRecipients(Message.RecipientType.TO, failureEmailIds);

					message.setContent(frmtdBodyMsg, "text/html");

					// Send message
					Transport.send(message);
					System.out.println("Email sent successfully");

				}

			} catch (IOException e) {
				System.out.println(Utils.getStackTrace(e));
			} catch (EncryptedDocumentException e) {
				System.out.println(Utils.getStackTrace(e));
			} catch (InvalidFormatException e) {
				System.out.println(Utils.getStackTrace(e));
			} catch (ParseException e) {
				System.out.println(Utils.getStackTrace(e));
			} catch (AddressException e) {
				System.out.println(Utils.getStackTrace(e));
			} catch (MessagingException e) {
				System.out.println(Utils.getStackTrace(e));
			} finally {
				if (csvReader != null)
					try {
						csvReader.close();
					} catch (IOException e) {
					}

			}
		}

	}

}