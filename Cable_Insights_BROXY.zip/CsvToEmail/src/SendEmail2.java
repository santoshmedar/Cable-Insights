import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFRow;

import com.opencsv.CSVReader;

public class SendEmail2 {

	DateFormat folderDateFormate = new SimpleDateFormat("yyyy-MM-dd");
	DateFormat fileDateFormate = new SimpleDateFormat("MMddyyyy");
	DateFormat standardDateFormat = new SimpleDateFormat("M/d/yyyy");
	DateFormat startTimeFormat = new SimpleDateFormat("hh:mm a");
	DateFormat dayOfWeekDateFormat = new SimpleDateFormat("EEEE");

	String programCompDir = "D:\\Cable_Insights\\Time_Period_Comparison\\";
	String rptPmrDir = "D:\\Cable_Insights\\Time_Period_Comparison_Rpt_Pmr\\";
	String compNetsDir = "D:\\Cable_Insights\\BROXY_Network_Program_Comps\\";

	Address[] successEmailIds;
	Address[] failureEmailIds;

	void sendCsvAsEmail(){

		String from = "CableInsights-donotreply@nbcuni.com"; //change accordingly  
		String host = "nbcumail.inbcu.com";//or IP address  

		//Get the session object  
		Properties properties = System.getProperties();  
		properties.setProperty("mail.smtp.host", host);

		Workbook workbook = null;

		File[] pgmCompFiles = new File(programCompDir).listFiles();
		File[] compNetsFiles = new File(compNetsDir).listFiles();

		if(pgmCompFiles.length!=0 || compNetsFiles.length !=0)
			try {
				System.out.println("Files found! waiting for complete files deplyment (2 mins)...");
				Thread.sleep(120000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				System.out.println(Utils.getStackTrace(e1));
			}

		Map<String, List<File>> pgmCompList = new TreeMap<>();
		Map<String, File> compNetList = new HashMap<>();

		for (File file : pgmCompFiles) {

			if(file.isFile()){
				String net = file.getName().split("-")[0].trim();

				//if(net.equals("Bravo") || net.equals("Oxygen") || net.equals("ENT")){
				if(net.equals("Bravo") || net.equals("Oxygen") || net.equals("ENT")){

					String date = file.getName().split("\\.")[1];
					List<File> filesList =pgmCompList.get(date);

					if(filesList!=null){
						filesList.add(file);
					}else{
						filesList = new ArrayList<>();
						filesList.add(file);
						pgmCompList.put(date, filesList);					
					}
				}
			}

		}

		for (File file : compNetsFiles) {

			if(file.isFile()){
				String date = file.getName().split("\\.")[1];
				compNetList.put(date, file);
			}

		}

		Set<String> allDates = new TreeSet<>();
		allDates.addAll(pgmCompList.keySet());
		allDates.addAll(compNetList.keySet());

		for (String fileDate : allDates) {
			System.out.println("Running for "+fileDate+"...");
			try {
				String frmtdBodyMsg = "<body style=\"font-family: 'Calibri','sans-serif';\">"+
						"<b style=\"font-size: 13.0pt;color: black;font-weight: bold;\"> <u> Bravo, E! & Oxygen Daily Ratings </u> </b><br>"+dayOfWeekDateFormat.format(fileDateFormate.parse(fileDate))+" "+standardDateFormat.format(fileDateFormate.parse(fileDate))+
						"<br> <i style=\"font-size: 10.2pt;\">Premieres are in bold and compared to the prior four week rolling season average, all other telecasts are compared to the prior four week time period average. </i><br>";



				if(pgmCompList.get(fileDate)!=null && pgmCompList.get(fileDate).size()==3 &&compNetList.get(fileDate)!=null){
					
					File[] pgmCompFileList = pgmCompList.get(fileDate).toArray(new File[3]);
					File compNetFile = compNetList.get(fileDate);
					DataFormatter dataFormatter = new DataFormatter();


					Map<String, String[]> netDemos = new HashMap<>();
					netDemos.put("BRVO", new String[]{"P18-49","P25-54"});
					//netDemos.put("BRAVO", netDemos.remove("BRVO"));

					netDemos.put("OXYG", new String[]{"P18-49","W25-54"});
					//netDemos.put("OXYGEN", netDemos.remove("OXYG"));

					netDemos.put("ENT", new String[]{"P18-49","W18-34"});
					//netDemos.put("E!", netDemos.remove("ENT"));

					//netDemos.put("USA", new String[]{"P18-49","P25-54"});
					//netDemos.put("SYFY", new String[]{"P18-49","P2+","P25-54"});
					Map<String, String> Demo = new HashMap<>();
					Demo.put("BRVO", "BRAVO");
					Demo.put("OXYG", "OXYGEN");
					Demo.put("ENT", "E!");



					Map<Integer, String> colWidths = new HashMap<>();
					colWidths.put(0, "100px");
					colWidths.put(1, "204px");
					colWidths.put(2, "186px");
					colWidths.put(3, "60px");
					colWidths.put(4, "60px");

					Map<Integer, String> demoBgColors = new HashMap<>();
					//demoBgColors.put(0, "#E2EFDA");
					//demoBgColors.put(1, "#FFF2CC");
					//demoBgColors.put(2, "#ffe6e6");



					demoBgColors.put(0, "#e6f5ff");
					demoBgColors.put(1, "#fff9e6");
					demoBgColors.put(2, "#f1f7ed");

					File rptPmrFile = null;
					for (File file : new File(rptPmrDir).listFiles()) {
						if(file.getName().contains(fileDate) && file.getName().contains("BROXY"))
							rptPmrFile = file;
					}

					if(rptPmrFile != null){

						System.out.println("Program Comparison, Comp. Network and Indicators files found for "+fileDate);
						
						Workbook rptPmrWrkbook = WorkbookFactory.create(rptPmrFile);
						Sheet rptPmrSheet = rptPmrWrkbook.getSheetAt(0);

						Map<String, Integer> rptPmrCols = new HashMap<>();
						for (int i = 0; i < rptPmrSheet.getRow(0).getLastCellNum(); i++) 
							rptPmrCols.put(dataFormatter.formatCellValue(rptPmrSheet.getRow(0).getCell(i)), i);

						Map<String, Boolean> colsRptPmr = new HashMap<>();
						Map<String, Boolean> colsGenres = new HashMap<>();

						System.out.println("Loading data from Indicators file...");
						System.out.println(rptPmrFile);
						
						for (int i = 1; i <= rptPmrSheet.getLastRowNum() ; i++) {

							String net = dataFormatter.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("Net"))); 
							String show = dataFormatter.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("Show Name")));
							String startTime = startTimeFormat.parse(dataFormatter.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("Start Time")))).toString();
							String rptPmr = dataFormatter.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("P/R")));
							String genre = dataFormatter.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("Genre")));
							String movie = dataFormatter.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("Movie")));
							
							if(rptPmrCols.get("Non Commercial") != null){
								String nonCommInd = dataFormatter.formatCellValue(rptPmrSheet.getRow(i).getCell(rptPmrCols.get("Non Commercial")));
								
								if(nonCommInd.trim().equals("") && (rptPmr.trim().equals("") || rptPmr.trim().equals("P")))
									colsRptPmr.put(net+show+startTime, true);
							}else{
								if(rptPmr.trim().equals("") || rptPmr.trim().equals("P"))
									colsRptPmr.put(net+show+startTime, true);
							}

							colsGenres.put(net+show+startTime, (genre.equalsIgnoreCase("FF") || movie.equalsIgnoreCase("M") ? true : false));
						}

						rptPmrWrkbook.close();

						System.out.println("Processing Program Comparison files...");
						
						for (File filePath : pgmCompFileList) {
							
							System.out.println(filePath);
							workbook = WorkbookFactory.create(filePath);

							Sheet sheet = workbook.getSheetAt(0);

							Map<String, Integer> colsTobeTaken = new HashMap<>(); 
							Map<String, int[]> fltrData = new TreeMap<>();
							List<String> dates = new ArrayList<>();


							boolean firstRow = true;

							String network = dataFormatter.formatCellValue(sheet.getRow(0).getCell(0));
							String date = dataFormatter.formatCellValue(sheet.getRow(1).getCell(0));

							List<Integer> validColInd = new ArrayList<>();


							frmtdBodyMsg += "<br>"
									+ "<span style=\"font-size:14.0pt;color:black;font-family:'Calibri','sans-serif';font-weight: bold;\">"+Demo.get(network)+"</span>"
									+ "<br>"
									+ "<table style=\"width: 1000;white-space: nowrap;border-collapse: collapse;font-size: 12pt;font-family: 'Calibri','sans-serif';text-align: right;border: 1px solid black;\">"
									+ "<thead> "
									+ "<tr style=\"background-color:#737373;border-color: #737373;color: white;\">";

							String headerHtml = "<th style=\"text-align:left;padding:5px;%s;\"> %s </th>";


							for (int i = 0; i < sheet.getRow(4).getLastCellNum(); i++){
								/*if(i==2)
									continue;*/


								boolean validDemos = false;
								for (String demo : netDemos.get(network))

									//if(data.get(0)[i].contains(demo)){
									if(sheet.getRow(4).getCell(i).toString().contains(demo) || (i > 0 &&sheet.getRow(4).getCell(i-1).toString().contains(demo) )){
										validDemos = true;
										break;
									}


								if( i <= 2 ||validDemos){

									String colName = dataFormatter.formatCellValue(sheet.getRow(4).getCell(i));
									//dataFormatter.formatCellValue(sheet.getRow(1).getCell(0));
									colName = colName.replace("_x000d_\nLS_x000d_\nImps_x000d_\n(000)", " (000)");
									colName = colName.replace("% Diff _x000d_\n Vs. _x000d_\n Prior 4 Weeks", "% vp4w");

									if(i <= 2)
										frmtdBodyMsg+=String.format(headerHtml, "width:"+colWidths.get(i), colName);
									else if(i % 2 == 1)
										frmtdBodyMsg+=String.format(headerHtml, "text-align:center;width:"+colWidths.get(5), colName);
									//style+="color:blue;";
									else 
										frmtdBodyMsg+=String.format(headerHtml, "text-align:center;width:"+colWidths.get(6), colName);

									validColInd.add(i);
								}
							}

							frmtdBodyMsg+="</tr> </thead> <tbody>";

							//HSSFRow row = null;
							for (int i = 5; i <= sheet.getLastRowNum(); i++) {

								frmtdBodyMsg+="<tr>";
								int demoColInd = 0;
								Row row =  sheet.getRow(i);

								String netShowTime = null;

								try{
									netShowTime = network+dataFormatter.formatCellValue(row.getCell(1))+startTimeFormat.parse(dataFormatter.formatCellValue(row.getCell(0))).toString();
								}catch(ParseException e){}
								//for (int j = 2; j < data.get(i).length; j++){
								for (int j = 0; j < row.getLastCellNum(); j++){

									/*if(j==2)
										continue;*/

									if(validColInd.indexOf(j) >= 0){

										String td = null;

										//String td = "<td style=\"%s\">"+data.get(i)[j] sheet.getRow(i).getCell(j)+"</td>";
										String style = "text-align:center;padding-right:5px;padding-left:5px;";

										if(colsRptPmr.get(netShowTime) != null && colsRptPmr.get(netShowTime))
											style+="font-weight:bold;";

										if(j <= 2)
											style+="text-align:left;padding-left:5px;";

										else if((j-2)%2 == 1)
											style+="text-align:center;background:"+demoBgColors.get(demoColInd++)+";";

										if((i == sheet.getLastRowNum()-1 || i == sheet.getLastRowNum()))
											style+="font-weight:bold;border-top:1px solid black;";

										//if(i == data.size()-2)
										if(i == sheet.getLastRowNum()-1)
											style+="background:#D9D9D9;";

										else if(i == sheet.getLastRowNum())
											style+="background:#BFBFBF;";

										String percval = dataFormatter.formatCellValue(sheet.getRow(i).getCell(j));

										if(j>2 && (j%2)==0 && percval != null && !percval.equals("") && Integer.parseInt(percval.split("%")[0])<0)
											style+="text-align:center;color:red;";

										if(j>2 && (j%2)==0 && percval != null && !percval.equals("") && Integer.parseInt(percval.split("%")[0])>0)
											style+="text-align:center;color:green;";

										if(j>2 && (j%2)==0){
											if(percval != null && !percval.equals("")){
												if(Integer.parseInt(percval.split("%")[0])>0)
													td = "<td style=\""+style+"\">+"+ percval+"</td>";
												else
													td = "<td style=\""+style+"\">"+ percval+"</td>";
											}else
												td = "<td></td>";
										} else if(j == 1 || j == 2){
											String showName = dataFormatter.formatCellValue(sheet.getRow(i).getCell(j));
											/*if(j == 2 && (colsGenres.get(netShowTime)==null || !colsGenres.get(netShowTime)))
												showName = "";*/
											
											showName = (showName.length() > 23) ? (showName.substring(0, 23)+"...") : showName;
											
											td = "<td style=\""+style+"\">"+ showName +"</td>";
										}
										else 
											td = "<td style=\""+style+"\">"+ dataFormatter.formatCellValue(sheet.getRow(i).getCell(j))+"</td>";

										frmtdBodyMsg+=td;
									}
								}

								frmtdBodyMsg+="</tr>";
							}

							frmtdBodyMsg+="</tbody> </table>";

							workbook.close();
						}

						frmtdBodyMsg+="<br>"
								+ "<span style=\"font-size:14.0pt;color:black;font-family:'Calibri','sans-serif';font-weight: bold;\"> Competition (New Episodes only) </span>"
								+ "<br>"
								+ "<table style=\"width:750px;white-space: nowrap;border-collapse: collapse;font-family: 'Calibri','sans-serif';text-align: right;border: 1px solid black;\">"
								+ "<thead><tr style=\"background-color:gray;border-color: black;color: white;\">";


						frmtdBodyMsg+="<th style=\"padding-left:5px;padding-right:5px;text-align:left;width: 70px;\">Net</th>";
						frmtdBodyMsg+="<th style=\"padding-left:5px;padding-right:5px;text-align:left;\">Show Name</th>";
						frmtdBodyMsg+="<th style=\"padding-left:5px;padding-right:5px;text-align:left;\">Start Time</th>";
						frmtdBodyMsg+="<th style=\"padding-left:5px;padding-right:5px;text-align:center;\">P18-49 (000)</th>";
						frmtdBodyMsg+="<th style=\"padding-left:5px;padding-right:5px;text-align:center;\">Prior Week %Diff</th>";

						frmtdBodyMsg+="</tr></thead><tbody>";

						System.out.println("Processing Comp. Network file...");
						System.out.println(compNetFile);
						
						workbook = WorkbookFactory.create(compNetFile);

						Sheet sheet = workbook.getSheetAt(0);

						Map<String, Integer> colsTobeTaken = new HashMap<>(); 
						Map<String, int[]> fltrData = new TreeMap<>();
						List<String> dates = new ArrayList<>();

						String[] posDiffColors = {"#c8e1b7","#bad9a5","#acd293","#9eca81","#91c36f","#83bb5d","#75b44b","#69a244","#5e903c","#527e35"};
						//String[] negDiffColors = {"#fee7e7","#fdcece","#fcb6b6","#fb9d9d","#fa8585","#f96c6c","#f85454","#f73b3b","#f62323","#f50a0a"};
						String[] negDiffColors = {"#ffdacc","#ffc7b3","#ffb499","#ffa280","#ff8f66","#ff7f50","#ff7c4d","#ff6933","#ff571a","#ff4400"};

						boolean firstRow = true;
						for (Row row : sheet) {

							if(firstRow){
								int cellCount = 0;
								for (Cell cell : row) {
									if(dataFormatter.formatCellValue(cell).equals("Net"))
										colsTobeTaken.put("Net", cellCount);
									else if(dataFormatter.formatCellValue(cell).equals("Show Name"))
										colsTobeTaken.put("Show Name", cellCount);
									else if(dataFormatter.formatCellValue(cell).equals("Rounded Start Time"))
										colsTobeTaken.put("Start Time", cellCount);
									else if(dataFormatter.formatCellValue(cell).equals("Daypart"))
										colsTobeTaken.put("Daypart", cellCount);
									else if(dataFormatter.formatCellValue(cell).equals("Demo"))
										colsTobeTaken.put("Demo", cellCount);
									else if(dataFormatter.formatCellValue(cell).equals("Genre"))
										colsTobeTaken.put("Genre", cellCount);
									else if(dataFormatter.formatCellValue(cell).equals("Movie"))
										colsTobeTaken.put("Movie", cellCount);
									else if(dataFormatter.formatCellValue(cell).equals("Episode"))
										colsTobeTaken.put("Episode", cellCount);
									else if(dataFormatter.formatCellValue(cell).contains("Imps")){
										colsTobeTaken.put(dataFormatter.formatCellValue(cell), cellCount);
										dates.add(dataFormatter.formatCellValue(cell));
									}


									cellCount++;
								}
								firstRow = false;
							}else{

								String imps1 = dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get(dates.get(0)))).trim();
								String imps2 = dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get(dates.get(1)))).trim();
								String Genre = dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get("Genre")));
								String Movie = dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get("Movie")));

								int impsval1 = (imps1.equals("")) ? 0 : Integer.parseInt(imps1);
								int impsval2 = (imps2.equals("")) ? 0 : Integer.parseInt(imps2);

								Date dateFrmt1 = standardDateFormat.parse(dates.get(0).split("\n")[0].trim());
								Date dateFrmt2 = standardDateFormat.parse(dates.get(1).split("\n")[0].trim());

								int currImps = 0, prevImps=0;

								if(dateFrmt1.after(dateFrmt2)){
									currImps = impsval1;
									prevImps = impsval2;
								}else {
									currImps = impsval2;
									prevImps = impsval1;
								}

								String demo = dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get("Demo"))); 
								String daypart = dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get("Daypart")));
								String network = dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get("Net")));
								String Episode = dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get("Episode"))); 
								String ShowName = dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get("Show Name")));

								if(demo.equals("P18-49") && daypart.equals("M-Su 6P - 12A") && !network.equals("BRVO")){

									String fltrRow = dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get("Net")));

									fltrRow += "\t"+dataFormatter.formatCellValue(row.getCell(colsTobeTaken.get("Start Time")));


									if(Genre.equals("FF") || Movie.equals("M")){

										String showEpi = ShowName+" ("+Episode+")"; 

										fltrRow += "\t"+ ((showEpi.length() > 28) ? (showEpi.substring(0,28)+"...") : showEpi);

									}


									else
										fltrRow += "\t"+ShowName;


									if(fltrData.get(fltrRow) != null){
										fltrData.get(fltrRow)[0] += currImps;
										fltrData.get(fltrRow)[1] += prevImps;

										if(currImps!=0)
											fltrData.get(fltrRow)[2]++;
										if(prevImps != 0)
											fltrData.get(fltrRow)[3]++;
									}else{
										int currImpsCount = 0;
										int prevImpsCount = 0;

										if(currImps!=0)
											currImpsCount = 1;
										if(prevImps != 0)
											prevImpsCount = 1;

										fltrData.put(fltrRow, new int[]{currImps, prevImps, currImpsCount,prevImpsCount});

									}

								}
							}
						}

						String prevNet = null;
						
						for (Entry<String, int[]> row : fltrData.entrySet()) {

							int currImps = (row.getValue()[2] == 0) ? 0 : (int)Math.round(row.getValue()[0]*1.0/row.getValue()[2]);
							int prevImps = (row.getValue()[3] == 0) ? 0 : (int)Math.round(row.getValue()[1]*1.0/row.getValue()[3]);

							String network = row.getKey().split("\t")[0];
							String showName = row.getKey().split("\t")[2];

							if(currImps == 0 || (network.equalsIgnoreCase("HBOM") && showName.equalsIgnoreCase("BREAK")))
								continue;

							int impsDiff = (prevImps==0)? 100 : (int)Math.round((currImps-prevImps)*100.0/prevImps);

							String bgColor = "white";

							if(impsDiff != 100)
								if(impsDiff > 0)
									bgColor = posDiffColors[impsDiff/10 >= 10 ? 9 : (impsDiff/10)];
								else if(impsDiff < 0)
									bgColor = negDiffColors[impsDiff/10 <= -10 ? 9 : Math.abs(impsDiff/10)];


							if(prevNet == null){
								prevNet = network;
							}else if(!prevNet.equals(network)){
								
								frmtdBodyMsg+="<tr> <td style=\"height: 15px;\"> </td><td> </td><td> </td><td> </td><td> </td></tr>";
								prevNet = network;
							}
							
							frmtdBodyMsg+="<tr>";
							frmtdBodyMsg+="<td style=\"padding-left:5px;padding-right:5px;text-align:left;\">"+network+"</td>";
							frmtdBodyMsg+="<td style=\"padding-left:5px;padding-right:5px;text-align:left;\">"+showName+"</td>";
							frmtdBodyMsg+="<td style=\"padding-left:5px;padding-right:5px;text-align:left;\">"+row.getKey().split("\t")[1]+"</td>";
							frmtdBodyMsg+="<td style=\"padding-left:5px;padding-right:5px;text-align:center;\">"+currImps+"</td>";
							frmtdBodyMsg+="<td style=\"padding-left:5px;padding-right:5px;text-align:center;background-color:"+bgColor+";\">"+((impsDiff == 100)?"N/A":(impsDiff+"%"))+"</td>";
							frmtdBodyMsg+="</tr>";

						}

						frmtdBodyMsg+="</tbody></table>";

						System.out.println("Tables are successfully created.");
						System.out.println("Sending email...");
						
						String emailSub = "BROXY - Cable Insights - "+standardDateFormat.format(fileDateFormate.parse(fileDate));
						/*to = new Address[]{ 

								//new InternetAddress("ted.linhart@nbcuni.com"),
								//new InternetAddress("kerry.billings@nbcuni.com"),
								//new InternetAddress("Jennifer.Livolsi@nbcuni.com"),

								//new InternetAddress("dara.levine@nbcuni.com"),
								//new InternetAddress("Keanna.Harper@nbcuni.com"),
								//new InternetAddress("Jacqueline.Xu@nbcuni.com"),
								//new InternetAddress("Ziauddin.Mohammed@nbcuni.com"),

								//new InternetAddress("Neda.Garemani@nbcuni.com"),
								//new InternetAddress("Vaneet.Kumar@nbcuni.com"),
								new InternetAddress("santhosh.medar@nbcuni.com"),
								//new InternetAddress("Kondapa.Chittabathina@nbcuni.com"),
								//new InternetAddress("Kratika.Sharma@nbcuni.com")
						};*/

						Session session = Session.getDefaultInstance(properties);  

						//compose the message  

						MimeMessage message = new MimeMessage(session);
						message.setSubject(emailSub);
						message.setFrom(new InternetAddress(from));  
						message.addRecipients(Message.RecipientType.TO,successEmailIds);  

						message.setContent(frmtdBodyMsg, "text/html");

						// Send message  
						Transport.send(message);  
						System.out.println("Email sent successfully");

						System.out.println("Moving files to processed folder...");
						//move files to archive

						
						File destDirectory = new File("D:\\Cable_Insights\\BROXY_Archive\\"+folderDateFormate.format(new Date()));


						for (File file : pgmCompFileList)
						{
							File destFile = new File(destDirectory.getAbsolutePath()+"\\"+file.getName());
							if(destFile.exists())
							{
								destFile.delete();
								System.out.println(destFile.getAbsolutePath()+" file deleted since it alreday exists");
							}

							try {
								FileUtils.moveFileToDirectory(file, destDirectory, true);
								System.out.println(file.getName()+" is successfully moved to "+destDirectory.getAbsolutePath());
							} catch (IOException e) {
								System.out.println(new Date().toString() + " Failed to move Excel files to archive folder!");

							}

						}

						workbook.close();
						File destFile = new File(destDirectory.getAbsolutePath()+"\\"+compNetFile.getName());
						//File destFile = new File(destDirectory.getAbsolutePath()+"\\"+compNetList.get(fileDate));

						if(destFile.exists())
						{
							destFile.delete();
							System.out.println(destFile.getAbsolutePath()+" file deleted since it alreday exists");
						}

						try {
							FileUtils.moveFileToDirectory(compNetFile, destDirectory, true);
							System.out.println(compNetFile.getName()+" is successfully moved to "+destDirectory.getAbsolutePath());
						} catch (IOException e) {
							System.out.println(new Date().toString() + " Failed to move Excel files to archive folder!");

						}

						File rptPmrDestFile = new File(destDirectory.getAbsolutePath()+"\\"+rptPmrFile.getName());
						//File destFile = new File(destDirectory.getAbsolutePath()+"\\"+compNetList.get(fileDate));

						if(rptPmrDestFile.exists())
						{
							rptPmrDestFile.delete();
							System.out.println(rptPmrDestFile.getAbsolutePath()+" file deleted since it alreday exists");
						}

						try {
							FileUtils.moveFileToDirectory(rptPmrFile, destDirectory, true);
							System.out.println(rptPmrFile.getName()+" is successfully moved to "+destDirectory.getAbsolutePath());
						} catch (IOException e) {
							System.out.println(new Date().toString() + " Failed to move Excel files to archive folder!");

						}

					}else{
						
						System.out.println("Repeat/Premier Indicator file not found for "+standardDateFormat.format(fileDateFormate.parse(fileDate)));
				
						System.out.println("Sending email internally...");
						frmtdBodyMsg="<p> Repeat/Premier Indicator file not found for "+standardDateFormat.format(fileDateFormate.parse(fileDate))+"</p>";				

						Session session = Session.getDefaultInstance(properties);  

						//compose the message  
						String emailSub = "BROXY - Cable Insights - "+standardDateFormat.format(fileDateFormate.parse(fileDate));
						MimeMessage message = new MimeMessage(session);
						message.setSubject(emailSub);
						message.setFrom(new InternetAddress(from));  
						message.addRecipients(Message.RecipientType.TO,failureEmailIds);  

						message.setContent(frmtdBodyMsg, "text/html");

						// Send message  
						Transport.send(message);  
						System.out.println("Email sent successfully");
					}


				}else{

					if(pgmCompList.get(fileDate) == null){
						System.out.println("There are no Time Period Comparison files found for "+fileDate);
						frmtdBodyMsg = "<p>There are no Time Period Comparison files found for "+fileDate+".</p>";
					}
					else if(pgmCompList.get(fileDate).size()!=3){
						System.out.println("There are less or more than 3 files found for Time Period Comparison for "+fileDate);
						frmtdBodyMsg = "<p>There are less or more than 3 files found for Time Period Comparison for "+fileDate+".</p>";
					}

					if(compNetList.get(fileDate)==null){
						System.out.println("Network Program Comparison file not found for "+standardDateFormat.format(fileDateFormate.parse(fileDate)));
						frmtdBodyMsg ="<p> Network Program Comparison file not found for "+standardDateFormat.format(fileDateFormate.parse(fileDate))+"</p>";
					}

					System.out.println("Sending email internally...");
					Session session = Session.getDefaultInstance(properties);  

					//compose the message  
					String emailSub = "BROXY - Cable Insights - "+standardDateFormat.format(fileDateFormate.parse(fileDate));
					MimeMessage message = new MimeMessage(session);
					message.setSubject(emailSub);
					message.setFrom(new InternetAddress(from));  
					message.addRecipients(Message.RecipientType.TO,failureEmailIds);  

					message.setContent(frmtdBodyMsg, "text/html");

					// Send message  
					Transport.send(message);  
					System.out.println("Email sent successfully");
				}


			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println(Utils.getStackTrace(e));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(Utils.getStackTrace(e));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				System.out.println(Utils.getStackTrace(e));
			} catch (EncryptedDocumentException e) {
				// TODO Auto-generated catch block
				System.out.println(Utils.getStackTrace(e));
			} catch (InvalidFormatException e) {
				// TODO Auto-generated catch block
				System.out.println(Utils.getStackTrace(e));
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				System.out.println(Utils.getStackTrace(e));
			}finally{
				if(workbook != null)
					try {
						workbook.close();
					} catch (IOException e) {}
			}
		}
	}

	//}


	public static void main(String[] args) {

		String[] emailIds = System.getProperty("emailIds").split(",");

		SendEmail2 sendEmail = new SendEmail2();

		sendEmail.successEmailIds = new InternetAddress[emailIds.length];

		try {

			System.out.println("Loading email ids from arguments...");
			for (int i = 0; i < emailIds.length; i++)
				sendEmail.successEmailIds[i] = new InternetAddress(emailIds[i]);

			sendEmail.failureEmailIds = new Address[] {

					new InternetAddress("Vaneet.Kumar@nbcuni.com"),
					new InternetAddress("santhosh.medar@nbcuni.com"),
					new InternetAddress("Kratika.Sharma@nbcuni.com") 
			};

			sendEmail.sendCsvAsEmail();
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			System.out.println(Utils.getStackTrace(e));
		}
	}
}
