import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.text.html.parser.Entity;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Email {

	DateFormat folderDateFormate = new SimpleDateFormat("yyyy-MM-dd");
	DateFormat fileDateFormate = new SimpleDateFormat("MMddyyyy");
	DateFormat standardDateFormat = new SimpleDateFormat("M/d/yyyy");
	DateFormat startTimeFormat = new SimpleDateFormat("hh:mm a");
	DateFormat dayOfWeek = new SimpleDateFormat("EEEE");
	DateFormat subDateFormat = new SimpleDateFormat("EEE M/d");

	String programCompDir = "D:\\BH_Reports\\Time_Period_Comparison\\TPC\\";
	//String rptPmrDir = "D:\\Cable_Ent_Insights\\Time_Period_Comparison_Rpt_Pmr\\";
	String L3LSDir = "D:\\BH_Reports\\Time_Period_Comparison\\BH\\";
	//String ranking = "D:\\Cable_Ent_Insights\\Ranking\\";

	String from = "CableInsights-donotreply@nbcuni.com"; //change accordingly  
	String host = "nbcumail.inbcu.com";//or IP address  
	String emailSub = "NBCU Cable Ent. Insights - ";

	Properties properties = null;

	Address[] successRecipients;
	Address[] failureRecipients;

	public Email() {
		// TODO Auto-generated constructor stub
		properties = System.getProperties();  
		properties.setProperty("mail.smtp.host", host);
	}

	void readExcelFiles(){

		try {
			Date dpStartTime = startTimeFormat.parse("06:00 PM");
			Date dpEndTime = startTimeFormat.parse("11:59 PM");

			//Get the session object  

			Workbook workbook = null;

			File[] pgmCompFiles = new File(programCompDir).listFiles();
			File[] L3LSFiles = new File(L3LSDir).listFiles();
			//File[] rankingFiles = new File(ranking).listFiles();

			if(pgmCompFiles.length!=0 || L3LSFiles.length !=0)
				try {
					System.out.println(new Date().toString()+" source file(s) found in the source directory. Waiting for 2 minutes...");
					Thread.sleep(120000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1.getMessage()+"\n"+Utils.getStackTrace(e1));
				}

			Map<String, List<File>> pgmCompList = new TreeMap<>();
			Map<String, File> L3LSFilesList = new HashMap<>();
			//Map<String, File> cableRanking = new HashMap<>();
			//Map<String, File> bCastRanking = new HashMap<>();


			for (File file : pgmCompFiles) {

				if(file.isFile()){
					String net = file.getName().split("�")[0].split("_")[1].trim();

					//if(net.equals("Bravo") || net.equals("Oxygen") || net.equals("ENT")){
					if(net.equalsIgnoreCase("Brvo") || net.equalsIgnoreCase("Oxygen") || net.equalsIgnoreCase("ENT")|| net.equalsIgnoreCase("USA") || net.equalsIgnoreCase("SYFY")){

						String date = file.getName().split("\\.")[1];
						List<File> filesList =pgmCompList.get(date);

						if(filesList!=null){
							filesList.add(file);
						}else{
							filesList = new ArrayList<>();
							filesList.add(file);
							pgmCompList.put(date, filesList);					
						}
					}
				}

			}

			for (File file : L3LSFiles) {

				if(file.isFile()){
					String date = file.getName().split("\\.")[1];
					L3LSFilesList.put(date, file);
				}

			}

			Set<String> allDates = new TreeSet<>();
			allDates.addAll(pgmCompList.keySet());
			allDates.addAll(L3LSFilesList.keySet());			

			for (String fileDate : allDates) {

				System.out.println(new Date()+" processing files for "+fileDate);

				try {
					String frmtdBodyMsg = "<body style=\"font-family: 'Calibri','sans-serif';\">"+
							"<b style=\"font-size: 14pt;color: black;\"> <u> NBCU Cable Entertainment Insights - "+dayOfWeek.format(fileDateFormate.parse(fileDate))+", "+standardDateFormat.format(fileDateFormate.parse(fileDate))+" </u> </b><br>"+
							"<b style=\"font-size: 12pt;color:red;\">These Insights are designed for this group only - please do not forward.</b><br><br>"
							+ "<u style=\"font-weight: bold;font-size: 13pt;\"> NBCU Cable Entertainment Networks - Prime Programs </u> "
							+ "<br> <b> <i style=\"font-size:11pt;color:#7030A0;\">Premieres are in bold and compared to the prior week, all other telecasts are compared to the prior four week time period average.</i></b>";

					if(pgmCompList.get(fileDate)!=null && pgmCompList.get(fileDate).size()==5 &&L3LSFilesList.get(fileDate)!=null 
							//&& cableRanking.get(fileDate)!=null && bCastRanking.get(fileDate)!=null
							){

						System.out.println(new Date()+" The number of files is correct and proceeding for data extraction");

						File[] pgmCompFileList = pgmCompList.get(fileDate).toArray(new File[5]);

						File[] sortedPgmList = new File[5];

						for (File file : pgmCompFileList) {
							if(file.getName().contains("USA"))
								sortedPgmList[0] = file;
							else if(file.getName().contains("BRVO"))
								sortedPgmList[1] = file;
							else if(file.getName().contains("ENT"))
								sortedPgmList[2] = file;
							else if(file.getName().contains("SYFY"))
								sortedPgmList[3] = file;
							else 
								sortedPgmList[4] = file;

						}

						File L3LSFile = L3LSFilesList.get(fileDate);
						DataFormatter dataFormatter = new DataFormatter();


						Map<String, String[]> netDemos = new HashMap<>();
						netDemos.put("BRVO", new String[]{"P18-49","P25-54"});
						netDemos.put("OXYG", new String[]{"P18-49","P25-54"});
						netDemos.put("ENT", new String[]{"P18-49","P25-54"});
						netDemos.put("USA", new String[]{"P18-49","P25-54"});
						netDemos.put("SYFY", new String[]{"P18-49","P25-54"});

						Map<String, String> netDisplayNames = new HashMap<>();
						netDisplayNames.put("BRVO", "BRAVO");
						netDisplayNames.put("OXYG", "OXYGEN");
						netDisplayNames.put("ENT", "E!");
						netDisplayNames.put("USA", "USA");
						netDisplayNames.put("SYFY", "SYFY");



						Map<Integer, String> colWidths = new HashMap<>();
						colWidths.put(0, "14%");
						colWidths.put(1, "30%");

						Map<Integer, String> demoBgColors = new HashMap<>();
						//demoBgColors.put(0, "#E2EFDA");
						//demoBgColors.put(1, "#FFF2CC");
						//demoBgColors.put(2, "#ffe6e6");



						demoBgColors.put(0, "#e6f5ff");
						demoBgColors.put(1, "#fff9e6");
						demoBgColors.put(2, "#f1f7ed");

						System.out.println(new Date().toString()+" Reading L3 vs LS file...");
						workbook = WorkbookFactory.create(L3LSFile);

						Sheet sheet = workbook.getSheetAt(0);

						Map<String, Integer> columns = new HashMap<>();
						Map<String, String[]> lsL3Data = new HashMap<>();
						Map<String, String[]> lsL3DataForTPC = new HashMap<>();

						for (int i = 0; i < sheet.getRow(0).getLastCellNum(); i++)
							columns.put(dataFormatter.formatCellValue(sheet.getRow(0).getCell(i)), i);						

						for (int i = 1; i <= sheet.getLastRowNum(); i++) {

							Row row = sheet.getRow(i);

							String netType = dataFormatter.formatCellValue(row.getCell(columns.get("Network Type")));
							String net = dataFormatter.formatCellValue(row.getCell(columns.get("Net")));
							String showName = dataFormatter.formatCellValue(row.getCell(columns.get("Show Name")));
							String startTime = dataFormatter.formatCellValue(row.getCell(columns.get("Rounded Start Time")));
							String dispStartTime = dataFormatter.formatCellValue(row.getCell(columns.get("Start Time")));
							String stream = dataFormatter.formatCellValue(row.getCell(columns.get("Stream")));
							String allInds = dataFormatter.formatCellValue(row.getCell(columns.get("All Inds")));
							String demo = dataFormatter.formatCellValue(row.getCell(columns.get("Demo")));
							String date = dataFormatter.formatCellValue(row.getCell(columns.get("Date")));
							String imps = dataFormatter.formatCellValue(row.getCell(columns.get("Imps")));
							String dateDesc = dataFormatter.formatCellValue(row.getCell(columns.get("Date Desc")));
							String genre = dataFormatter.formatCellValue(row.getCell(columns.get("Genre")));
							String episode = dataFormatter.formatCellValue(row.getCell(columns.get("Episode")));

							lsL3Data.put(netType+"~"+net+"~"+showName+"~"+startTimeFormat.parse(startTime)+"~"+stream+"~"+demo+"~"+dateDesc, new String[]{allInds, date, imps, genre, episode, dispStartTime});

							if(net.equalsIgnoreCase("BRVO") 
							|| net.equalsIgnoreCase("OXYG") 
							|| net.equalsIgnoreCase("ENT") 
							|| net.equalsIgnoreCase("USA") 
							|| net.equalsIgnoreCase("SYFY"))
								lsL3DataForTPC.put(netType+"~"+net+"~"+showName+"~"+startTimeFormat.parse(dispStartTime)+"~"+stream+"~"+demo+"~"+dateDesc, new String[]{allInds, date, imps, genre, episode, startTime});


							
						}

						if(workbook != null)
							workbook.close();

						System.out.println(new Date()+" bindig data for \"NBCU Cable Entertainment Networks - Prime Programs\"");

						for (File filePath : sortedPgmList) {
							workbook = WorkbookFactory.create(filePath);

							sheet = workbook.getSheetAt(0);

							Map<String, Integer> colsTobeTaken = new HashMap<>(); 
							Map<String, int[]> fltrData = new TreeMap<>();
							List<String> dates = new ArrayList<>();


							boolean firstRow = true;

							String network = dataFormatter.formatCellValue(sheet.getRow(0).getCell(0));
							String date = dataFormatter.formatCellValue(sheet.getRow(1).getCell(0));

							List<Integer> validColInd = new ArrayList<>();

							System.out.println(new Date()+" binding for "+network+" network");

							frmtdBodyMsg += "<br>"
									+ "<span style=\"font-size:13pt;\"><b><u>"+netDisplayNames.get(network)+"</u></b></span>"
									+ "<br>"
									+ "<table style=\"width:850px;white-space: nowrap;border-collapse: collapse;font-size: 12pt;font-family: 'Calibri','sans-serif';text-align: right;border: 1px solid black;\">"
									+ "<thead> "
									+ "<tr style=\"background-color:#737373;border-color: #737373;color: white;\">";

							String headerHtml = "<th style=\"text-align:left;padding:5px;%s;\"> %s </th>";


							for (int i = 0; i < sheet.getRow(4).getLastCellNum(); i++){
								if(i==2)
									continue;


								boolean validDemos = false;
								for (String demo : netDemos.get(network))

									//if(data.get(0)[i].contains(demo)){
									if(sheet.getRow(4).getCell(i).toString().contains(demo) || (i > 0 &&sheet.getRow(4).getCell(i-1).toString().contains(demo) )){
										validDemos = true;
										break;
									}


								if( i <= 2 ||validDemos){

									String colName = dataFormatter.formatCellValue(sheet.getRow(4).getCell(i));
									//dataFormatter.formatCellValue(sheet.getRow(1).getCell(0));
									colName = colName.replace("_x000d_\nLS_x000d_\nImps_x000d_\n(000)", " (000)");
									colName = colName.replace("% Diff _x000d_\n Vs. _x000d_\n Prior 4 Weeks", "% Dif");

									if(i <= 2)
										frmtdBodyMsg+=String.format(headerHtml, "width:"+colWidths.get(i), colName);
									/*else if(i % 2 == 1)
										frmtdBodyMsg+=String.format(headerHtml, "text-align:center;width:"+colWidths.get(i), colName);*/									
									else 
										frmtdBodyMsg+=String.format(headerHtml, "text-align:center;width:14%", colName);

									validColInd.add(i);
								}
							}

							frmtdBodyMsg+="</tr> </thead> <tbody>";

							//HSSFRow row = null;
							for (int i = 5; i <= sheet.getLastRowNum(); i++) {

								Row row =  sheet.getRow(i);

								Date startTime = null;


								startTime = startTimeFormat.parse(dataFormatter.formatCellValue(row.getCell(0)));

								if(startTime.before(dpStartTime) || startTime.after(dpEndTime))
									continue;

								frmtdBodyMsg+="<tr>";
								int demoColInd = 0;

								String showName = dataFormatter.formatCellValue(row.getCell(1));

								String[] metrics = lsL3DataForTPC.get("Cable~"+network+"~"+showName+"~"+startTime+"~LS~P18-49~Current Broadcast Date");

								if(metrics != null){


									for (int j = 0; j < row.getLastCellNum(); j++){

										if(j==2)
											continue;

										if(validColInd.indexOf(j) >= 0){

											String td = null;

											String style = "text-align:center;padding-right:5px;padding-left:5px;";

											if((!showName.equalsIgnoreCase("SYFY MOVIE")) && !metrics[0].contains("R"))
												style+="font-weight:bold;";

											if(j <= 2)
												style+="text-align:left;padding-left:5px;";
											else if((j-2)%2 == 1)
												style+="text-align:center;background:"+demoBgColors.get(demoColInd++)+";";

											if(j>2 && (j%2)==0){

												int diff = Integer.parseInt(dataFormatter.formatCellValue(sheet.getRow(i).getCell(j)).split("%")[0]);

												if((!showName.equalsIgnoreCase("SYFY MOVIE")) && !metrics[0].contains("R")){
													String demo = dataFormatter.formatCellValue(sheet.getRow(4).getCell(j-1)).split("\n")[0];
													String[] priorWkMetrics = lsL3Data.get("Cable~"+network+"~"+showName+"~"+startTimeFormat.parse(metrics[5])+"~LS~"+demo+"~Prior 7 Broadcast Date");

													if(priorWkMetrics != null){
														if(priorWkMetrics[0].contains("R"))
															priorWkMetrics = null;
													}else{
														
														List<String[]> matchedEntries = new ArrayList<>();
														
														for (Entry<String, String[]> entry : lsL3Data.entrySet()) {
															
															String prevNetType = entry.getKey().split("~")[0];
															String prevNet = entry.getKey().split("~")[1];
															String prevShowName = entry.getKey().split("~")[2];
															String prevStream = entry.getKey().split("~")[4];
															String prevDemo = entry.getKey().split("~")[5];	
															String prevDateDesc = entry.getKey().split("~")[6];
															
															if(prevNetType.equals("Cable")
															&& prevNet.equals(network)
															&& prevShowName.equals(showName)
															&& prevStream.equals("LS")
															&& prevDemo.equals(demo)
															&& prevDateDesc.equals("Prior 7 Broadcast Date")
															&& !entry.getValue()[0].contains("R"))
																matchedEntries.add(entry.getValue());
															
														}
														
														if(matchedEntries.size()==1)
															priorWkMetrics = matchedEntries.get(0);
													}
													
													if(priorWkMetrics != null ){
														int prevImps = Integer.parseInt(priorWkMetrics[2]);

														int currImps = Integer.parseInt(dataFormatter.formatCellValue(sheet.getRow(i).getCell(j-1)));

														diff = Math.round((float)((currImps-prevImps)*100.0/prevImps));
													}else{

														diff = Integer.MAX_VALUE;

														System.out.println("Not found: Cable - "+network+" - "+showName+" - "+startTimeFormat.format(startTime)+" - LS - "+demo+" Prior 7 broadcast date");
													}


												}

												if(diff <0)
													style+="text-align:center;color:red;";
												else if(diff>0 && diff < Integer.MAX_VALUE)
													style+="text-align:center;color:green;";

												if(diff > 0 && diff < Integer.MAX_VALUE)
													td = "<td style=\""+style+"\">+"+ diff+"%</td>";
												else if(diff == Integer.MAX_VALUE)
													td = "<td style=\""+style+"\">NA</td>";
												else
													td = "<td style=\""+style+"\">"+ diff+"%</td>";

											}else if(j == 1){

												String tmpShow = showName;

												if(metrics[0].contains("M") || metrics[3].contains("FF"))
													tmpShow +=" ("+dataFormatter.formatCellValue(sheet.getRow(i).getCell(2))+")";

												tmpShow = (tmpShow.length() > 23) ? (tmpShow.substring(0, 23)+"...") : tmpShow;

												td = "<td style=\""+style+"\">"+ tmpShow +"</td>";
											}else
												td = "<td style=\""+style+"\">"+ dataFormatter.formatCellValue(sheet.getRow(i).getCell(j))+"</td>";

											frmtdBodyMsg+=td;



										}

									}
								}else{
									System.out.println("Not found: Cable - "+network+" - "+showName+" - "+startTime+" - LS - P18-49 - Current Broadcast Date");
								}

								frmtdBodyMsg+="</tr>";
							}

							frmtdBodyMsg+="</tbody> </table>";

							workbook.close();
						}

						System.out.println(new Date()+" bindig data for \"Top 20 Cable Original Premieres\"");
						//Top 20 Cable Original Premieres

						frmtdBodyMsg+="<br><br>"
								+ "<span style=\"font-size:13pt;\"><b><u>Top 20 Cable Originals:</u></b></span>"
								+ "<br> <span style=\"font-size:11pt;\">New episodes only - cable entertainment networks only, excludes sports and news programming, *=season premiere vs prior season premiere</span>";

						frmtdBodyMsg+="<br><table style=\"width: 600;white-space: nowrap;border-collapse: collapse;font-size: 13pt;font-family: 'Calibri','sans-serif';text-align: right;border: 1px solid black;\">"
								+ "<thead>"
								+ "<tr style=\"vertical-align: bottom;background-color:#737373;color: white;\">"
								+ "<th colspan=\"4\"></th>"
								+"<th style=\"width: 65px;text-align: center;\"> LS</th>"
								+ "<th></th>"
								+ "</tr>"
								+ "<tr style=\"vertical-align: bottom;background-color:#737373;color: white;\">"
								+ "<th colspan=\"4\"></th>"
								+"<th style=\"width: 65px;text-align: center;\"> P18-49</th>"
								+ "<th style=\"width: 65px;text-align: center;\">Vs Prior</th>"
								+ "</tr>"
								+ "<tr style=\"vertical-align: bottom;background-color:#737373;color: white;\">"
								+"<th style=\"text-align: left;width: 50px;\"> Rank </th>"
								+"<th style=\"text-align: left;width: 50px;\"> Net </th>"
								+"<th style=\"text-align: left;width: 200px;\"> Show Name </th>"
								+"<th style=\"text-align: left;width: 85px;\"> Start Time </th>"
								+"<th style=\"width: 65px;text-align: center;\">Imps</th>"
								+"<th style=\"width: 65px;text-align: center;\">Week</th>"
								+"</tr> </thead>"
								+ "<tbody>";

						TreeSet<Entry<String, Integer>> top20CablesEntries = new TreeSet<>(new Comparator<Entry<String, Integer>>() {
							@Override
							public int compare(Entry<String, Integer> entry1, Entry<String, Integer> entry2) {
								// TODO Auto-generated method stub
								int diff = entry2.getValue() - entry1.getValue();

								if(diff == 0){
									diff = entry1.getKey().split("~")[0].compareTo(entry2.getKey().split("~")[0]);

									if(diff == 0)
										diff = entry1.getKey().split("~")[2].compareTo(entry2.getKey().split("~")[2]);
								}

								return diff;							

							}
						});

						Map<String, Integer> top20Cable = new HashMap<>();

						for (Entry<String, String[]> row : lsL3Data.entrySet()) {

							String netType = row.getKey().split("~")[0];
							String net = row.getKey().split("~")[1];
							String stream = row.getKey().split("~")[4];
							String demo = row.getKey().split("~")[5];
							String dateDesc = row.getKey().split("~")[6];

							String[] currDateMetrics = row.getValue();
							String showName = row.getKey().split("~")[2];
							
							if(netType.equalsIgnoreCase("Cable") && stream.equalsIgnoreCase("LS") && demo.equalsIgnoreCase("P18-49") && dateDesc.equalsIgnoreCase("Current Broadcast Date") 
									&& !currDateMetrics[0].contains("R") 
									&& !currDateMetrics[3].equalsIgnoreCase("N")
									&& !currDateMetrics[3].equalsIgnoreCase("SA")
									&& !currDateMetrics[3].equalsIgnoreCase("SC")
									&& !currDateMetrics[3].equalsIgnoreCase("SE")
									&& !currDateMetrics[3].equalsIgnoreCase("SN")
									&& !net.equalsIgnoreCase("CNN")
									&& !net.equalsIgnoreCase("MSNBC")
									&& !net.equalsIgnoreCase("FOXNC")
									&& !showName.equalsIgnoreCase("SYFY MOVIE")){

								
								
								String startTime = row.getKey().split("~")[3];
								String dispStartTime = currDateMetrics[5];

								int currImps =Integer.parseInt(currDateMetrics[2]);
								
								String[] priorDateMetrics = lsL3Data.get("Cable~"+net+"~"+showName+"~"+startTime+"~LS~P18-49~Prior 7 Broadcast Date");
								
								if(priorDateMetrics != null){
									if(priorDateMetrics[0].contains("R"))
										priorDateMetrics = null;
								}else{
									
									List<String[]> matchedEntries = new ArrayList<>();
									
									for (Entry<String, String[]> entry : lsL3Data.entrySet()) {
										
										String prevNetType = entry.getKey().split("~")[0];
										String prevNet = entry.getKey().split("~")[1];
										String prevShowName = entry.getKey().split("~")[2];
										String prevStream = entry.getKey().split("~")[4];
										String prevDemo = entry.getKey().split("~")[5];	
										String prevDateDesc = entry.getKey().split("~")[6];
										
										if(prevNetType.equals("Cable")
										&& prevNet.equals(net)
										&& prevShowName.equals(showName)
										&&prevStream.equals("LS")
										&&prevDemo.equals("P18-49")
										&& prevDateDesc.equals("Prior 7 Broadcast Date")
										&& !entry.getValue()[0].contains("R"))
											matchedEntries.add(entry.getValue());
										
									}
									
									if(matchedEntries.size()==1)
										priorDateMetrics = matchedEntries.get(0);
								}
								
								if(currDateMetrics[0].contains("M") || currDateMetrics[3].contains("FF"))
									showName +=" ("+currDateMetrics[4]+")";

								showName = (showName.length() > 23) ? (showName.substring(0, 23)+"...") : showName;

								if(currDateMetrics[0].contains("P"))
									showName="*"+showName;
								
								if(priorDateMetrics != null){

									int prevImps =Integer.parseInt(priorDateMetrics[2]);

									int diff = Math.round((float)((currImps-prevImps)*100.0/prevImps));

									top20Cable.put(net+"~"+showName+"~"+dispStartTime+"~"+diff, currImps);
								}else{
									top20Cable.put(net+"~"+showName+"~"+dispStartTime+"~"+Integer.MAX_VALUE, currImps);

									System.out.println("Prior 7 broadcast Date data not found for below entry\n"
											+ "Cable - "+net+" - "+showName+" - "+startTimeFormat.format(new Date(startTime))+" - LS - P18-49");
								}



							}

						}

						top20CablesEntries.addAll(top20Cable.entrySet());

						int rank = 0, count = 0;
						int tempImps = Integer.MAX_VALUE;

						Map<String, String> intNetsColors = new HashMap<>();

						intNetsColors.put("BRVO", "#d8f1f3");
						intNetsColors.put("USA", "#d6f5d6");
						intNetsColors.put("SYFY", "#b3d1ff");
						intNetsColors.put("ENT", "#ffe0cc");
						intNetsColors.put("OXYG", "#ffcce5");

						for (Entry<String, Integer> entry : top20CablesEntries) {

							String[] key = entry.getKey().split("~");

							if(!(key[0].equalsIgnoreCase("HBOM") && (key[1].equalsIgnoreCase("*BREAK") || key[1].equalsIgnoreCase("BREAK"))) && !key[0].equalsIgnoreCase("TWC")){

								count++;
								
								if(tempImps == Integer.MAX_VALUE || tempImps != entry.getValue()){
									rank = count;
									tempImps = entry.getValue();
								}

								if(rank <= 25){

									int diff = Integer.parseInt(key[3]);

									frmtdBodyMsg += "<tr style=\"background-color:"+intNetsColors.get(key[0])+";"+(intNetsColors.get(key[0]) != null ? "font-weight: bold;" : "")+"\">"
											+ "<td style=\"text-align: left; padding-left: 5px;\">"+rank+"</td>"
											+ "<td style=\"text-align: left; padding-left: 5px;\">"+key[0]+"</td>"
											+ "<td style=\"text-align: left; padding-left: 5px;\">"+key[1]+"</td>"
											//+ "<td style=\"text-align: left; padding-left: 5px;\">"+startTimeFormat.format(new Date(key[2]))+"</td>"
											+ "<td style=\"text-align: left; padding-left: 5px;\">"+key[2]+"</td>"
											+ "<td style=\"text-align: center;\">"+entry.getValue()+"</td>";

									if(diff == Integer.MAX_VALUE)
										frmtdBodyMsg+="<td style=\"text-align: center;\">NA</td>";
									else if(diff > 0)
										frmtdBodyMsg+="<td style=\"text-align: center;color:green;\">+"+diff+"%</td>";
									else if(diff < 0)
										frmtdBodyMsg+="<td style=\"text-align: center;color:red;\">"+diff+"%</td>";
									else
										frmtdBodyMsg+="<td style=\"text-align: center;\">"+diff+"%</td>";

									frmtdBodyMsg+="</tr>";

								}else 
									break;
							}
						}

						frmtdBodyMsg+="</tbody> </table>";

						System.out.println(new Date()+" bindig data for \"Broadcast Programs Rank\"");
						// Broadcast Programs Rank

						frmtdBodyMsg+="<br><br><span style=\"font-size:13pt;\"><b><u>Broadcast Programs Rank:</u></b></span>"
								+ "<br> <span style=\"font-size:11pt;\">New episodes only - excluding sports and news, *=season premiere vs prior season premiere</span>"
								+ "<br>";

						frmtdBodyMsg+="<table style=\"width: 600;white-space: nowrap;border-collapse: collapse;font-size: 13pt;font-family: 'Calibri','sans-serif';text-align: right;border: 1px solid black;\">"
								+ "<thead>"
								+ "<tr style=\"vertical-align: bottom;background-color:#737373;color: white;\">"
								+ "<th colspan=\"4\"></th>"
								+"<th style=\"width: 65px;text-align: center;\"> LS</th>"
								+ "<th></th>"
								+ "</tr>"
								+ "<tr style=\"vertical-align: bottom;background-color:#737373;color: white;\">"
								+ "<th colspan=\"4\"></th>"
								+"<th style=\"width: 65px;text-align: center;\"> P18-49</th>"
								+ "<th style=\"width: 65px;text-align: center;\">Vs Prior</th>"
								+ "</tr>"
								+ "<tr style=\"vertical-align: bottom;background-color:#737373;color: white;\">"
								+"<th style=\"text-align: left;width: 50px;\"> Rank </th>"
								+"<th style=\"text-align: left;width: 50px;\"> Net </th>"
								+"<th style=\"text-align: left;width: 200px;\"> Show Name </th>"
								+"<th style=\"text-align: left;width: 85px;\"> Start Time </th>"
								+"<th style=\"width: 65px;text-align: center;\">Imps</th>"
								+"<th style=\"width: 65px;text-align: center;\">Week</th>"
								+"</tr> </thead>"
								+ "<tbody>";


						TreeSet<Entry<String, Integer>> bCastRnkEntries = new TreeSet<>(new Comparator<Entry<String, Integer>>() {
							@Override
							public int compare(Entry<String, Integer> entry1, Entry<String, Integer> entry2) {
								// TODO Auto-generated method stub
								int diff = entry2.getValue() - entry1.getValue();

								if(diff == 0){
									diff = entry1.getKey().split("~")[0].compareTo(entry2.getKey().split("~")[0]);

									if(diff == 0)
										diff = entry1.getKey().split("~")[2].compareTo(entry2.getKey().split("~")[2]);
								}

								return diff;
							}
						});

						Map<String, Integer> bCastRnk = new HashMap<>();

						for (Entry<String, String[]> row : lsL3Data.entrySet()) {

							String netType = row.getKey().split("~")[0];
							String stream = row.getKey().split("~")[4];
							String demo = row.getKey().split("~")[5];
							String dateDesc = row.getKey().split("~")[6];
							String net = row.getKey().split("~")[1];
							String startTime = row.getKey().split("~")[3];

							String[] currDateMetrics = row.getValue();
							String dispStartTime = currDateMetrics[5];
							
							Date startTimeFrmt = new Date(startTime);

							Calendar c =Calendar.getInstance();

							c.setTime(standardDateFormat.parse(currDateMetrics[1]));

							int dow = c.get(Calendar.DAY_OF_WEEK);

							if(netType.equalsIgnoreCase("Broadcast") && (net.equalsIgnoreCase("NBC") || 
									net.equalsIgnoreCase("CBS") ||
									net.equalsIgnoreCase("ABC") ||
									net.equalsIgnoreCase("FOX") ||
									net.equalsIgnoreCase("CW")) && stream.equalsIgnoreCase("LS") && demo.equalsIgnoreCase("P18-49") && dateDesc.equalsIgnoreCase("Current Broadcast Date") 
									&& !currDateMetrics[0].contains("R")
									&& !currDateMetrics[3].equalsIgnoreCase("N")
									&& !currDateMetrics[3].equalsIgnoreCase("SA")
									&& !currDateMetrics[3].equalsIgnoreCase("SC")
									&& !currDateMetrics[3].equalsIgnoreCase("SE")
									&& !currDateMetrics[3].equalsIgnoreCase("SN")
									&& ((dow >= 2 && dow <= 7 && startTimeFrmt.after(startTimeFormat.parse("07:59 PM")) && startTimeFrmt.before(startTimeFormat.parse("11:00 PM"))) || 
											(dow == 1 && startTimeFrmt.after(startTimeFormat.parse("06:59 PM")) && startTimeFrmt.before(startTimeFormat.parse("11:00 PM"))))){

								String showName = row.getKey().split("~")[2];

								String[] priorDateMetrics = lsL3Data.get("Broadcast~"+net+"~"+showName+"~"+startTime+"~LS~P18-49~Prior 7 Broadcast Date");
								
								if(priorDateMetrics != null){
									if(priorDateMetrics[0].contains("R"))
										priorDateMetrics = null;
								}else{
									
									List<String[]> matchedEntries = new ArrayList<>();
									
									for (Entry<String, String[]> entry : lsL3Data.entrySet()) {
										
										String prevNetType = entry.getKey().split("~")[0];
										String prevNet = entry.getKey().split("~")[1];
										String prevShowName = entry.getKey().split("~")[2];
										String prevStream = entry.getKey().split("~")[4];
										String prevDemo = entry.getKey().split("~")[5];	
										String prevDateDesc = entry.getKey().split("~")[6];
										
										if(prevNetType.equals("Broadcast")
										&& prevNet.equals(net)
										&& prevShowName.equals(showName)
										&&prevStream.equals("LS")
										&&prevDemo.equals("P18-49")
										&& prevDateDesc.equals("Prior 7 Broadcast Date")
										&& !entry.getValue()[0].contains("R"))
											matchedEntries.add(entry.getValue());
										
									}
									
									if(matchedEntries.size()==1)
										priorDateMetrics = matchedEntries.get(0);
								}
								
								int currImps =Integer.parseInt(currDateMetrics[2]);

								if(currDateMetrics[0].contains("M") || currDateMetrics[3].contains("FF"))
									showName +=" ("+currDateMetrics[4]+")";

								showName = (showName.length() > 23) ? (showName.substring(0, 23)+"...") : showName;

								if(currDateMetrics[0].contains("P"))
									showName = "*"+showName;

								if(priorDateMetrics != null){

									int prevImps =Integer.parseInt(priorDateMetrics[2]);

									int diff = Math.round((float)((currImps-prevImps)*100.0/prevImps));

									bCastRnk.put(net+"~"+showName+"~"+dispStartTime+"~"+diff, currImps);
								}else{

									bCastRnk.put(net+"~"+showName+"~"+dispStartTime+"~"+Integer.MAX_VALUE, currImps);

									System.out.println("Prior 7 broadcast Date data not found for below entry\n"
											+ "Cable - "+net+" - "+showName+" - "+startTimeFormat.format(new Date(startTime))+" - LS - P18-49");
								}


							}

						}

						bCastRnkEntries.addAll(bCastRnk.entrySet());

						rank = 0;
						count = 0;
						tempImps = Integer.MAX_VALUE;
						for (Entry<String, Integer> entry : bCastRnkEntries) {

							String[] key = entry.getKey().split("~");
							int diff = Integer.parseInt(key[3]);

							count++;
							
							if(tempImps == Integer.MAX_VALUE || tempImps != entry.getValue()){
								rank = count;
								tempImps = entry.getValue();
							}

							
							frmtdBodyMsg += "<tr>"
									+ "<td style=\"text-align: left; padding-left: 5px;\">"+rank+"</td>"
									+ "<td style=\"text-align: left; padding-left: 5px;\">"+key[0]+"</td>"
									+ "<td style=\"text-align: left; padding-left: 5px;\">"+key[1]+"</td>"
									//+ "<td style=\"text-align: left; padding-left: 5px;\">"+startTimeFormat.format(new Date(key[2]))+"</td>"
									+ "<td style=\"text-align: left; padding-left: 5px;\">"+key[2]+"</td>"
									+ "<td style=\"text-align: center;\">"+entry.getValue()+"</td>";

							if(diff == Integer.MAX_VALUE)
								frmtdBodyMsg+="<td style=\"text-align: center;\">NA</td>";
							else if(diff > 0)
								frmtdBodyMsg+="<td style=\"text-align: center;color:green;\">+"+diff+"%</td>";
							else if(diff < 0)
								frmtdBodyMsg+="<td style=\"text-align: center;color:red;\">"+diff+"%</td>";
							else
								frmtdBodyMsg+="<td style=\"text-align: center;\">"+diff+"%</td>";

							frmtdBodyMsg+="</tr>";

						}

						frmtdBodyMsg+="</tbody> </table>";

						System.out.println(new Date()+" binding data for \"Portfolio Originals - L3 vs LS\"");
						// L3 vs LS

						Date priorWkBcastDate = null;

						Map<String, Integer[]> portfolioL3Ls = new HashMap<>();

						for (Entry<String, String[]> row : lsL3Data.entrySet()) {

							String netType = row.getKey().split("~")[0];
							String net = row.getKey().split("~")[1];
							String showName = row.getKey().split("~")[2];
							String startTime = row.getKey().split("~")[3];
							String stream = row.getKey().split("~")[4];
							String demo = row.getKey().split("~")[5];
							String dateDesc = row.getKey().split("~")[6];

							String[] metrics = row.getValue();
							String dispStartTime = metrics[5];
							
							if(dateDesc.equalsIgnoreCase("Prior 7 Broadcast Date") &&
									demo.equalsIgnoreCase("P18-49") && 
									!metrics[0].contains("R")
									&& !metrics[3].equalsIgnoreCase("N")
									&& !metrics[3].equalsIgnoreCase("SA")
									&& !metrics[3].equalsIgnoreCase("SC")
									&& !metrics[3].equalsIgnoreCase("SE")
									&& !metrics[3].equalsIgnoreCase("SN")
									&& !net.equalsIgnoreCase("CNN")
									&& !net.equalsIgnoreCase("MSNBC")
									&& !net.equalsIgnoreCase("FOXNC")
									&& !net.equalsIgnoreCase("TWC")
									&& !showName.equalsIgnoreCase("SYFY MOVIE")
									&& !(net.equalsIgnoreCase("HBOM")
										&& showName.equalsIgnoreCase("BREAK"))
									){

								if(priorWkBcastDate == null)
									priorWkBcastDate = standardDateFormat.parse(metrics[1]);

								if(metrics[0].contains("M") || metrics[3].contains("FF"))
									showName +=" ("+metrics[4]+")";

								showName = (showName.length() > 23) ? (showName.substring(0, 23)+"...") : showName;

								
								if(portfolioL3Ls.get(net+"~"+showName+"~"+startTime+"~"+netType+"~"+dispStartTime)!=null){

									Integer[] met = portfolioL3Ls.get(net+"~"+showName+"~"+startTime+"~"+netType+"~"+dispStartTime);

									if(stream.equalsIgnoreCase("LS"))
										met[0] = Integer.parseInt(metrics[2]);
									else 
										met[1] = Integer.parseInt(metrics[2]);

									if(met[0] != null && met[1] != null){
										Integer diff = met[1] - met[0];
										Integer lift = Math.round((float)(diff*100.0/met[0]));

										if(lift == 0)
											portfolioL3Ls.remove(net+"~"+showName+"~"+startTime+"~"+netType+"~"+dispStartTime);
										else{
											met[2] = diff;
											met[3] = lift;
										}		
									}
								}else{

									Integer[] met = new Integer[]{null, null, null, null};

									if(stream.equalsIgnoreCase("LS"))
										met[0] = Integer.parseInt(metrics[2]);
									else 
										met[1] = Integer.parseInt(metrics[2]);

									portfolioL3Ls.put(net+"~"+showName+"~"+startTime+"~"+netType+"~"+dispStartTime, met);
								}
							}
						}

						TreeSet<Entry<String, Integer[]>> dataEntrySet = new TreeSet<>(new Comparator<Entry<String, Integer[]>>() {

							@Override
							public int compare(Entry<String, Integer[]> entry1, Entry<String, Integer[]> entry2) {
								// TODO Auto-generated method stub

								if(entry1.getValue()[1] == null)
									System.out.println(entry1.getKey());

								if(entry2.getValue()[1] == null)
									System.out.println(entry2.getKey());

								int diff = entry2.getValue()[1] - entry1.getValue()[1];

								if(diff == 0){
									diff = entry1.getKey().split("~")[0].compareTo(entry2.getKey().split("~")[0]);

									if(diff == 0)
										diff = entry1.getKey().split("~")[2].compareTo(entry2.getKey().split("~")[2]);
								}

								return diff;
							}
						});

						dataEntrySet.addAll(portfolioL3Ls.entrySet());

						frmtdBodyMsg+="<br><br><span style=\"font-size:13pt;\"><b><u>Prior "+dayOfWeek.format(priorWkBcastDate)+"'s Originals on "+standardDateFormat.format(priorWkBcastDate)+" - L3 vs LS</u></b></span>"
								+ "<br><span style=\"font-size:11pt;\">New episodes only, excluding sports and news, sorted by L3, excludes programs with 0% lift</span>"
								+ "<br><br>"
								+ "<table style=\"width: 700px;white-space: nowrap;border-collapse: collapse;font-size: 13pt;font-family: 'Calibri','sans-serif';text-align: right;border: 1px solid black;\">"
								+ "<thead>"
								+ "<tr style=\"background-color:#737373;color: white;\"> "
								+ "<th colspan=\"3\" style=\"text-align: left;width:60%;\"> Portfolio Originals - L3 vs LS</th>"
								+ "<th style=\"text-align: center;width:10%;\"> LS </th>"
								+ "<th style=\"text-align: center;width:10%;\"> L3 </th>"
								+ "<th colspan=\"2\" srtyle=\"width:20%;\"></th> </tr>"
								+ "<tr style=\"vertical-align: bottom;background-color:#737373;color: white;\">"
								+"<th style=\"text-align: left;width: 10%;padding-left: 4px;\"> Net </th>"
								+"<th style=\"text-align: left;width: 35%;padding-left: 4px;\"> Show Name </th>"
								+"<th style=\"text-align: left;width: 11%;padding-left: 4px;\"> Start Time </th>"
								+"<th style=\"width: 10%;text-align: center;\"> P18-49<br>Imps</th>"
								+"<th style=\"width: 10%;text-align: center;\"> P18-49<br>Imps</th>"
								+"<th style=\"width: 10%;text-align: center;\"> Imps Chg </th>"
								+"<th style=\"width: 10%;text-align: center;\"> % Lift </th>"
								+"</tr> </thead>"
								+ "<tbody>";

						for (Entry<String, Integer[]> row : dataEntrySet){

							String[] key = row.getKey().split("~");
							Integer[] metrics = row.getValue();

							if(key[0].equalsIgnoreCase("BRVO") || key[0].equalsIgnoreCase("OXYG") || key[0].equalsIgnoreCase("ENT") || 
									key[0].equalsIgnoreCase("USA") || key[0].equalsIgnoreCase("SYFY")){
								frmtdBodyMsg+="<tr>"
										+ "<td style=\"text-align: left;padding-left: 4px;\">"+key[0]+"</td>"
										+ "<td style=\"text-align: left;padding-left: 4px;\">"+key[1]+"</td>"
										//+ "<td style=\"text-align: left;padding-left: 4px;\">"+startTimeFormat.format(new Date(key[2]))+"</td>"
										+ "<td style=\"text-align: left;padding-left: 4px;\">"+key[4]+"</td>"
										+ "<td style=\"text-align: center;\">"+metrics[0]+"</td>"
										+ "<td style=\"text-align: center;\">"+metrics[1]+"</td>"
										+ "<td style=\"text-align: center;\">"+metrics[2]+"</td>";


								if(metrics[3] > 0)
									frmtdBodyMsg+="<td style=\"text-align: center;background-color:#fff3cc;\">+"+metrics[3]+"%</td>";
								/*else if(metrics[3] < 0)
									frmtdBodyMsg+="<td style=\"text-align: center;color:red;\">"+metrics[3]+"%</td>";*/
								else
									frmtdBodyMsg+="<td style=\"text-align: center;background-color:#fff3cc;\">"+metrics[3]+"%</td>";

								frmtdBodyMsg+="</tr>";
							}
						}

						frmtdBodyMsg += "</tbody> </table>";

						System.out.println(new Date()+" binding data for \"Top 10 Cable Originals - L3 vs LS\"");
						// Top 10 Cable Networks
						frmtdBodyMsg+="<br>"
								+ "<table style=\"width: 700px;white-space: nowrap;border-collapse: collapse;font-size: 13pt;font-family: 'Calibri','sans-serif';text-align: right;border: 1px solid black;\">"
								+ "<thead>"
								+ "<tr style=\"background-color:#737373;color: white;\">"
								+ "<th colspan=\"3\" style=\"text-align: left;width:60%;\"> Top 10 Cable Originals - L3 vs LS</th> "
								+ "<th style=\"text-align: center;width:10%;\"> LS </th> "
								+ "<th style=\"text-align: center;width:10%;\"> L3 </th> "
								+ "<th colspan=\"2\" style=\"width:20%;\"></th> </tr>"
								+ "<tr style=\"vertical-align: bottom;background-color:#737373;color: white;\">"
								+"<th style=\"text-align: left;width: 10%;\"> Net </th>"
								+"<th style=\"text-align: left;width: 35%;\"> Show Name </th>"
								+"<th style=\"text-align: left;width: 11%;\"> Start Time </th>"
								+"<th style=\"width: 10%;text-align: center;\"> P18-49<br>Imps</th>"
								+"<th style=\"width: 10%;text-align: center;\"> P18-49<br>Imps</th>"
								+"<th style=\"width: 10%;text-align: center;\"> Imps Chg </th>"
								+"<th style=\"width: 10%;text-align: center;\"> % Lift </th>"
								+"</tr> </thead>"
								+ "<tbody>";

						count = 0;
						for (Entry<String, Integer[]> row : dataEntrySet){

							String[] key = row.getKey().split("~");
							Integer[] metrics = row.getValue();

							if(key[3].equalsIgnoreCase("Cable") && count < 10){
								frmtdBodyMsg+="<tr>"
										+ "<td style=\"text-align: left;padding-left: 4px;\">"+key[0]+"</td>"
										+ "<td style=\"text-align: left;padding-left: 4px;\">"+key[1]+"</td>"
										//+ "<td style=\"text-align: left;padding-left: 4px;\">"+startTimeFormat.format(new Date(key[2]))+"</td>"
										+ "<td style=\"text-align: left;padding-left: 4px;\">"+key[4]+"</td>"
										+ "<td style=\"text-align: center;\">"+metrics[0]+"</td>"
										+ "<td style=\"text-align: center;\">"+metrics[1]+"</td>"
										+ "<td style=\"text-align: center;\">"+metrics[2]+"</td>";

								if(metrics[3] > 0)
									frmtdBodyMsg+="<td style=\"text-align: center;background-color:#fff3cc;\">+"+metrics[3]+"%</td>";
								/*else if(metrics[3] < 0)
									frmtdBodyMsg+="<td style=\"text-align: center;color:red;\">"+metrics[3]+"%</td>";*/
								else
									frmtdBodyMsg+="<td style=\"text-align: center;background-color:#fff3cc;\">"+metrics[3]+"%</td>";

								frmtdBodyMsg+="</tr>";

								count++;
							}


						}

						frmtdBodyMsg += "</tbody> </table>";

						System.out.println(new Date()+" binding data for \"Broadcast Originals - L3 vs LS\"");
						// Broadcast L3 vs LS
						frmtdBodyMsg+="<br>"
								+ "<table style=\"width: 700px;white-space: nowrap;border-collapse: collapse;font-size: 13pt;font-family: 'Calibri','sans-serif';text-align: right;border: 1px solid black;\">"
								+ "<thead>"
								+ "<tr style=\"background-color:#737373;color: white;\">"
								+ "<th colspan=\"3\" style=\"text-align: left;width:60%;\"> Broadcast Originals - L3 vs LS</th>"
								+ "<th style=\"text-align: center;width:10%;\"> LS </th>"
								+ "<th style=\"text-align: center;width:10%;\"> L3 </th>"
								+ "<th colspan=\"2\" style=\"width:20%;\"></th> </tr>"
								+ "<tr style=\"vertical-align: bottom;background-color:#737373;color: white;\">"
								+"<th style=\"text-align: left;width: 10%;\"> Net </th>"
								+"<th style=\"text-align: left;width: 35%;\"> Show Name </th>"
								+"<th style=\"text-align: left;width: 11%;\"> Start Time </th>"
								+"<th style=\"width: 10%;text-align: center;\"> P18-49<br>Imps</th>"
								+"<th style=\"width: 10%;text-align: center;\"> P18-49<br>Imps</th>"
								+"<th style=\"width: 10%;text-align: center;\"> Imps Chg </th>"
								+"<th style=\"width: 10%;text-align: center;\"> % Lift </th>"
								+"</tr> </thead>"
								+ "<tbody>";

						for (Entry<String, Integer[]> row : dataEntrySet){

							String[] key = row.getKey().split("~");
							Integer[] metrics = row.getValue();

							Date startTimeFrmt = new Date(key[2]);

							Calendar c =Calendar.getInstance();

							c.setTime(priorWkBcastDate);

							int dow = c.get(Calendar.DAY_OF_WEEK);

							if(key[3].equalsIgnoreCase("Broadcast")
									&& (key[0].equalsIgnoreCase("NBC") || 
											key[0].equalsIgnoreCase("CBS") ||
											key[0].equalsIgnoreCase("ABC") ||
											key[0].equalsIgnoreCase("FOX") ||
											key[0].equalsIgnoreCase("CW"))
									&& ((dow >= 2 && dow <= 7 && startTimeFrmt.after(startTimeFormat.parse("07:59 PM")) && startTimeFrmt.before(startTimeFormat.parse("11:00 PM"))) || 
											(dow == 1 && startTimeFrmt.after(startTimeFormat.parse("06:59 PM")) && startTimeFrmt.before(startTimeFormat.parse("11:00 PM"))))){

								frmtdBodyMsg+="<tr>"
										+ "<td style=\"text-align: left;padding-left: 4px;\">"+key[0]+"</td>"
										+ "<td style=\"text-align: left;padding-left: 4px;\">"+key[1]+"</td>"
										//+ "<td style=\"text-align: left;padding-left: 4px;\">"+startTimeFormat.format(new Date(key[2]))+"</td>"
										+ "<td style=\"text-align: left;padding-left: 4px;\">"+key[4]+"</td>"
										+ "<td style=\"text-align: center;\">"+metrics[0]+"</td>"
										+ "<td style=\"text-align: center;\">"+metrics[1]+"</td>"
										+ "<td style=\"text-align: center;\">"+metrics[2]+"</td>";

								if(metrics[3] > 0)
									frmtdBodyMsg+="<td style=\"text-align: center;background-color:#fff3cc;\">+"+metrics[3]+"%</td>";
								/*else if(metrics[3] < 0)
									frmtdBodyMsg+="<td style=\"text-align: center;color:red;\">"+metrics[3]+"%</td>";*/
								else
									frmtdBodyMsg+="<td style=\"text-align: center;background-color:#fff3cc;\">"+metrics[3]+"%</td>";

								frmtdBodyMsg+="</tr>";
							}

						}

						frmtdBodyMsg += "</tbody> </table>";

						System.out.println(new Date()+" Data is successfully wrapped in HTML");

						//triggering email

						System.out.println(frmtdBodyMsg);
						sendEmail(successRecipients, frmtdBodyMsg, emailSub+subDateFormat.format(fileDateFormate.parse(fileDate)));

						//move files to archive

						System.out.println(new Date()+" Moving source files to Archive folder");

						File destDirectory = new File("D:\\BH_Reports\\Time_Period_Comparison\\Archive\\"+folderDateFormate.format(new Date()));


						for (File file : pgmCompFileList)
						{
							File destFile = new File(destDirectory.getAbsolutePath()+"\\"+file.getName());
							if(destFile.exists())
							{
								destFile.delete();
								System.out.println(new Date()+" "+destFile.getAbsolutePath()+" file deleted since it alreday exists");
							}

							try {
								FileUtils.moveFileToDirectory(file, destDirectory, true);
							} catch (IOException e) {
								System.out.println(new Date().toString() + " Failed to move "+file.getName()+" file to archive folder!");

							}

						}

						File destFile = new File(destDirectory.getAbsolutePath()+"\\"+L3LSFile.getName());
						//File destFile = new File(destDirectory.getAbsolutePath()+"\\"+compNetList.get(fileDate));

						if(destFile.exists())
						{
							destFile.delete();
							System.out.println(new Date()+" "+destFile.getAbsolutePath()+" file deleted since it alreday exists");
						}

						try {
							FileUtils.moveFileToDirectory(L3LSFile, destDirectory, true);
						} catch (IOException e) {
							System.out.println(new Date().toString() + " Failed to move "+L3LSFile.getName()+" file to archive folder!");

						}

						System.out.println(new Date()+" Done.");

					}else{

						String errorMsg = "";
						
						if(pgmCompList.get(fileDate) == null)
							errorMsg = "There are no Time Period Comparison files found for "+standardDateFormat.format(fileDateFormate.parse(fileDate));
						else if(pgmCompList.get(fileDate).size()!=5)
							errorMsg = "There are less or more than 5 files found for Time Period Comparison for "+standardDateFormat.format(fileDateFormate.parse(fileDate));
						else if(L3LSFilesList.get(fileDate)==null)
							errorMsg="L3 vs LS file not found for "+standardDateFormat.format(fileDateFormate.parse(fileDate));

						System.out.println(new Date()+" "+errorMsg);
						sendEmail(failureRecipients, "<p>"+errorMsg+"</p>", emailSub+subDateFormat.format(fileDateFormate.parse(fileDate)));
					}


				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage()+"\n"+Utils.getStackTrace(e));

					sendEmail(failureRecipients, "Process failed! Please check log file for more details.", emailSub+subDateFormat.format(fileDateFormate.parse(fileDate)));

				} catch (IOException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage()+"\n"+Utils.getStackTrace(e));
					sendEmail(failureRecipients, "Process failed! Please check log file for more details.", emailSub+subDateFormat.format(fileDateFormate.parse(fileDate)));

				}catch (EncryptedDocumentException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage()+"\n"+Utils.getStackTrace(e));
					sendEmail(failureRecipients, "Process failed! Please check log file for more details.", emailSub+subDateFormat.format(fileDateFormate.parse(fileDate)));

				} catch (InvalidFormatException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage()+"\n"+Utils.getStackTrace(e));

					sendEmail(failureRecipients, "Process failed! Please check log file for more details.", emailSub+subDateFormat.format(fileDateFormate.parse(fileDate)));

				}  catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage()+"\n"+Utils.getStackTrace(e));

					sendEmail(failureRecipients, "Process failed! Please check log file for more details.", emailSub+subDateFormat.format(fileDateFormate.parse(fileDate)));

				}finally{
					if(workbook != null)
						try {
							workbook.close();
						} catch (IOException e) {}
				}
			}
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1.getMessage()+"\n"+Utils.getStackTrace(e1));

			sendEmail(failureRecipients, "Process failed! Please check log file for more details.", emailSub);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			System.out.println(e1.getMessage()+"\n"+Utils.getStackTrace(e1));

			sendEmail(failureRecipients, "Process failed! Please check log file for more details.", emailSub);
		}
	}

	void sendEmail(Address[] to, String body, String subject){

		Session session = Session.getDefaultInstance(properties);  

		MimeMessage message = new MimeMessage(session);
		try {
			message.setSubject(subject);

			message.setFrom(new InternetAddress(from));  
			message.addRecipients(Message.RecipientType.TO,to);  

			message.setContent(body, "text/html");

			// Send message  
			Transport.send(message);  
			System.out.println(new Date()+" Email sent successfully");

		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage()+"\n"+Utils.getStackTrace(e));
		}catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage()+"\n"+Utils.getStackTrace(e));
		}
	}


	public static void main(String[] args) {

		String[] arguments = System.getProperty("args").split(" ");
		Map<String, String[]> emailIds = new HashMap<>();

		for(String ids : arguments) {

			String key = ids.split("=")[0];
			String values = ids.split("=")[1];

			emailIds.put(key, values.split(","));
		}

		Email email = new Email();

		email.successRecipients = new InternetAddress[emailIds.get("successIds").length];
		email.failureRecipients = new InternetAddress[emailIds.get("failureIds").length];

		try {

			for (int i = 0; i < email.successRecipients.length; i++)
				email.successRecipients[i] = new InternetAddress(emailIds.get("successIds")[i]);

			for (int i = 0; i < email.failureRecipients.length; i++)
				email.failureRecipients[i] = new InternetAddress(emailIds.get("failureIds")[i]);

			email.readExcelFiles();

		} catch (AddressException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage()+"\n"+Utils.getStackTrace(e));

			email.sendEmail(email.failureRecipients, "Process failed! Please check log file for more details.", email.emailSub);
		}catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage()+"\n"+Utils.getStackTrace(e));

			email.sendEmail(email.failureRecipients, "Process failed! Please check log file for more details.", email.emailSub);
		}

	}
}
